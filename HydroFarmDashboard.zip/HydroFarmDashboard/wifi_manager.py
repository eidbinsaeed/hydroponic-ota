"""
Wi-Fi network management module for Raspberry Pi Hydroponic Dashboard.
Uses nmcli (NetworkManager CLI) to scan, list, and connect to Wi-Fi networks.
"""

import subprocess
import logging
import re
import time
import threading
from typing import List, Dict, Any, Optional, Tuple

# Set up logging
logger = logging.getLogger(__name__)

class WiFiManager:
    """Manages Wi-Fi connections using NetworkManager CLI (nmcli)."""
    
    def __init__(self):
        """Initialize the Wi-Fi manager."""
        self.is_scanning = False
        self.last_scan_time = 0
        self.scan_results = []
        self.connection_status = {
            "active": False,
            "ssid": "",
            "signal": "",
            "security": "",
            "ip_address": "",
            "last_message": "",
            "last_error": ""
        }

    def is_nmcli_available(self) -> bool:
        """Check if nmcli is available on the system."""
        try:
            result = subprocess.run(
                ["which", "nmcli"], 
                capture_output=True, 
                text=True, 
                check=False
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Error checking nmcli availability: {e}")
            return False

    def scan_networks(self) -> List[Dict[str, Any]]:
        """
        Scan for available Wi-Fi networks.
        
        Returns:
            List of dictionaries containing network details
        """
        if self.is_scanning:
            logger.info("Scan already in progress, using cached results")
            return self.scan_results
        
        # Use cached results if scan was performed recently (within 30 seconds)
        current_time = time.time()
        if current_time - self.last_scan_time < 30 and self.scan_results:
            logger.info("Using cached scan results (< 30s old)")
            return self.scan_results
        
        self.is_scanning = True
        self.scan_results = []
        
        try:
            # Rescan networks
            logger.info("Initiating network scan...")
            subprocess.run(
                ["nmcli", "device", "wifi", "rescan"],
                capture_output=True,
                text=True,
                check=False
            )
            
            # Wait a moment for scan to complete
            time.sleep(2)
            
            # Get scan results
            result = subprocess.run(
                [
                    "nmcli", 
                    "-t", 
                    "-f", 
                    "SSID,SIGNAL,SECURITY,BSSID,MODE,CHAN", 
                    "device", 
                    "wifi", 
                    "list"
                ],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                logger.error(f"Error scanning networks: {result.stderr}")
                self.is_scanning = False
                return self.scan_results
            
            # Process scan results
            networks = {}
            for line in result.stdout.strip().split('\n'):
                if not line:
                    continue
                
                parts = line.split(':')
                if len(parts) < 6:
                    continue
                
                ssid, signal, security, bssid, mode, channel = parts[:6]
                
                # Skip empty SSIDs
                if not ssid:
                    continue
                
                # Update or add network entry (by SSID, keeping the strongest signal)
                if ssid not in networks or int(signal) > int(networks[ssid]["signal"]):
                    networks[ssid] = {
                        "ssid": ssid,
                        "signal": int(signal),
                        "security": "Secured" if security and security != "--" else "Open",
                        "security_type": security,
                        "bssid": bssid,
                        "mode": mode,
                        "channel": channel
                    }
            
            # Convert to list and sort by signal strength
            self.scan_results = list(networks.values())
            self.scan_results.sort(key=lambda x: x["signal"], reverse=True)
            
            logger.info(f"Found {len(self.scan_results)} networks")
            self.last_scan_time = current_time
            
        except Exception as e:
            logger.error(f"Error during network scan: {e}")
        finally:
            self.is_scanning = False
        
        return self.scan_results

    def get_active_connection(self) -> Dict[str, Any]:
        """
        Get information about the currently active Wi-Fi connection.
        
        Returns:
            Dictionary with connection details
        """
        connection = {
            "active": False,
            "ssid": "",
            "signal": "",
            "security": "",
            "ip_address": "",
            "last_message": "",
            "last_error": ""
        }
        
        try:
            # Check if connected to Wi-Fi
            result = subprocess.run(
                ["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status"],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                logger.error(f"Error getting connection status: {result.stderr}")
                return connection
            
            # Find Wi-Fi connection
            wifi_conn = None
            for line in result.stdout.strip().split('\n'):
                parts = line.split(':')
                if len(parts) < 4:
                    continue
                
                device, conn_type, state, ssid = parts[:4]
                if conn_type == "wifi" and state == "connected" and ssid:
                    wifi_conn = {
                        "device": device,
                        "ssid": ssid
                    }
                    break
            
            if not wifi_conn:
                return connection
            
            # Get connection details
            result = subprocess.run(
                ["nmcli", "-t", "-f", "GENERAL.CONNECTION,GENERAL.STATE", "device", "show", wifi_conn["device"]],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                logger.error(f"Error getting connection details: {result.stderr}")
                return connection
            
            # Get IP address
            ip_result = subprocess.run(
                ["nmcli", "-t", "-f", "IP4.ADDRESS", "device", "show", wifi_conn["device"]],
                capture_output=True,
                text=True,
                check=False
            )
            
            ip_address = ""
            if ip_result.returncode == 0:
                ip_match = re.search(r'IP4.ADDRESS\[1\]:(.*)', ip_result.stdout)
                if ip_match:
                    ip_address = ip_match.group(1).split('/')[0]
            
            # Get signal strength
            signal_result = subprocess.run(
                ["nmcli", "-t", "-f", "ACTIVE,SIGNAL,SECURITY", "device", "wifi", "list", "ifname", wifi_conn["device"]],
                capture_output=True,
                text=True,
                check=False
            )
            
            signal = ""
            security = ""
            if signal_result.returncode == 0:
                for line in signal_result.stdout.strip().split('\n'):
                    parts = line.split(':')
                    if len(parts) >= 3 and parts[0] == "yes":
                        signal = parts[1]
                        security = parts[2]
                        break
            
            connection = {
                "active": True,
                "ssid": wifi_conn["ssid"],
                "signal": signal,
                "security": security,
                "ip_address": ip_address
            }
            
        except Exception as e:
            logger.error(f"Error getting active connection: {e}")
        
        return connection

    def connect_to_network(self, ssid: str, password: Optional[str] = None) -> Tuple[bool, str]:
        """
        Connect to a Wi-Fi network.
        
        Args:
            ssid: Network SSID
            password: Network password (if required)
            
        Returns:
            Tuple of (success, message)
        """
        try:
            # Check if already connected to this network
            current = self.get_active_connection()
            if current["active"] and current["ssid"] == ssid:
                return True, f"Already connected to {ssid}"
            
            logger.info(f"Attempting to connect to {ssid}")
            
            # Build command based on whether password is provided
            if password:
                cmd = ["nmcli", "device", "wifi", "connect", ssid, "password", password]
            else:
                cmd = ["nmcli", "device", "wifi", "connect", ssid]
            
            # Start connection in a separate thread
            def connect_thread():
                try:
                    self.connection_status["last_message"] = f"Connecting to {ssid}..."
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        check=False,
                        timeout=30  # Set timeout to prevent hanging
                    )
                    
                    if result.returncode == 0:
                        self.connection_status["last_message"] = f"Successfully connected to {ssid}"
                        self.connection_status["last_error"] = ""
                        logger.info(f"Successfully connected to {ssid}")
                        
                        # Update connection status after a short delay
                        time.sleep(2)
                        self.connection_status.update(self.get_active_connection())
                    else:
                        error_msg = result.stderr.strip() or "Unknown error"
                        self.connection_status["last_message"] = f"Failed to connect to {ssid}"
                        self.connection_status["last_error"] = error_msg
                        logger.error(f"Failed to connect to {ssid}: {error_msg}")
                
                except subprocess.TimeoutExpired:
                    self.connection_status["last_message"] = f"Connection timeout"
                    self.connection_status["last_error"] = "Connection process took too long"
                    logger.error(f"Connection timeout for {ssid}")
                
                except Exception as e:
                    self.connection_status["last_message"] = f"Error connecting"
                    self.connection_status["last_error"] = str(e)
                    logger.error(f"Error connecting to {ssid}: {e}")
            
            # Start connection process in background
            threading.Thread(target=connect_thread, daemon=True).start()
            
            return True, f"Connection to {ssid} initiated"
            
        except Exception as e:
            logger.error(f"Error initiating connection to {ssid}: {e}")
            return False, f"Error: {str(e)}"

    def disconnect(self) -> Tuple[bool, str]:
        """
        Disconnect from the current Wi-Fi network.
        
        Returns:
            Tuple of (success, message)
        """
        try:
            current = self.get_active_connection()
            if not current["active"]:
                return True, "Not connected to any network"
            
            # Find the Wi-Fi device
            result = subprocess.run(
                ["nmcli", "-t", "-f", "DEVICE,TYPE", "device", "status"],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                return False, f"Error finding Wi-Fi device: {result.stderr}"
            
            wifi_device = None
            for line in result.stdout.strip().split('\n'):
                parts = line.split(':')
                if len(parts) >= 2 and parts[1] == "wifi":
                    wifi_device = parts[0]
                    break
            
            if not wifi_device:
                return False, "No Wi-Fi device found"
            
            # Disconnect from Wi-Fi
            result = subprocess.run(
                ["nmcli", "device", "disconnect", wifi_device],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode == 0:
                return True, f"Disconnected from {current['ssid']}"
            else:
                return False, f"Failed to disconnect: {result.stderr}"
            
        except Exception as e:
            logger.error(f"Error disconnecting: {e}")
            return False, f"Error: {str(e)}"

    def get_connection_status(self) -> Dict[str, Any]:
        """
        Get the current connection status.
        
        Returns:
            Dictionary with connection status details
        """
        # Update with the latest connection info
        connection = self.get_active_connection()
        
        # Merge with stored status messages
        status = {
            **self.connection_status,
            **connection
        }
        
        return status

# Create a singleton instance
wifi_manager = WiFiManager()