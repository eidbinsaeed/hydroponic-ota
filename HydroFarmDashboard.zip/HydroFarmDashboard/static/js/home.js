/**
 * Gets the local IP address and updates the QR code modal
 */
function updateLocalIPAddress() {
    const ipAddressElement = document.getElementById('qr-ip-address');
    
    if (ipAddressElement) {
        fetch('/api/local_ip')
            .then(response => response.json())
            .then(data => {
                ipAddressElement.textContent = data.url || 'Not available';
            })
            .catch(error => {
                console.error('Error fetching local IP:', error);
                ipAddressElement.textContent = 'Failed to retrieve';
            });
    }
}

// Initialize QR code display
document.addEventListener('DOMContentLoaded', function() {
    // Initialize QR code modal
    const qrModal = document.getElementById('qrCodeModal');
    if (qrModal) {
        qrModal.addEventListener('show.bs.modal', function() {
            updateLocalIPAddress();
        });
    }
});

/**
 * Calculates the next scheduled watering time for the plant tower pump
 * @param {Array} schedules - Array of schedule objects with start_time, end_time, and enabled properties
 * @param {boolean} enabled - Whether the plant tower pump scheduling is enabled
 */
function calculateNextPlantTowerWatering(schedules, enabled) {
    const nextScheduledRunEl = document.getElementById('nextScheduledRun');
    
    if (!nextScheduledRunEl) {
        return;
    }
    
    if (!enabled || !schedules || schedules.length === 0) {
        nextScheduledRunEl.textContent = 'Not scheduled';
        return;
    }
    
    // Get current time
    const now = new Date();
    const currentHours = now.getHours();
    const currentMinutes = now.getMinutes();
    const currentTimeStr = `${currentHours.toString().padStart(2, '0')}:${currentMinutes.toString().padStart(2, '0')}`;
    
    // Filter enabled schedules
    const enabledSchedules = schedules.filter(schedule => schedule.enabled);
    
    if (enabledSchedules.length === 0) {
        nextScheduledRunEl.textContent = 'No active schedules';
        return;
    }
    
    // Find the next scheduled start time
    let nextStart = null;
    let nextStartTime = null;
    
    // Check if any schedule is currently active
    for (const schedule of enabledSchedules) {
        if (schedule.start_time <= currentTimeStr && currentTimeStr < schedule.end_time) {
            nextScheduledRunEl.textContent = 'Running now';
            return;
        }
    }
    
    // Find the next scheduled start time
    for (const schedule of enabledSchedules) {
        if (schedule.start_time > currentTimeStr) {
            if (nextStart === null || schedule.start_time < nextStart) {
                nextStart = schedule.start_time;
                nextStartTime = schedule;
            }
        }
    }
    
    // If no future schedules today, find the earliest schedule for tomorrow
    if (nextStart === null) {
        enabledSchedules.sort((a, b) => a.start_time.localeCompare(b.start_time));
        nextStart = enabledSchedules[0].start_time;
        nextStartTime = enabledSchedules[0];
        nextScheduledRunEl.textContent = `Tomorrow ${formatTimeDisplay(nextStart)}`;
    } else {
        nextScheduledRunEl.textContent = `Today ${formatTimeDisplay(nextStart)}`;
    }
}

/**
 * Formats a time string from "HH:MM" to a more readable format
 * @param {string} timeStr - Time string in format "HH:MM"
 * @returns {string} - Formatted time string
 */
function formatTimeDisplay(timeStr) {
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours, 10);
    const minute = parseInt(minutes, 10);
    
    // Create a date object to use toLocaleTimeString
    const date = new Date();
    date.setHours(hour);
    date.setMinutes(minute);
    date.setSeconds(0);
    
    return date.toLocaleTimeString([], {hour: 'numeric', minute:'2-digit'});
}

/**
 * Simulates air pump operation based on configured interval and duration
 * @param {number} interval - The interval between pump cycles in minutes
 * @param {number} duration - The duration the pump runs each cycle in minutes
 */
function simulateAirPump(interval, duration) {
    // Convert to milliseconds
    const intervalMs = interval * 60 * 1000;
    const durationMs = duration * 60 * 1000;
    
    const pumpStatusEl = document.getElementById('pumpStatus');
    const pumpTimeEl = document.getElementById('pumpTime');
    
    // Get a consistent starting point based on the current time
    const now = new Date();
    const minutesSinceHour = now.getMinutes() % interval;
    const secondsSinceminute = now.getSeconds();
    const millisecondsSinceSecond = now.getMilliseconds();
    const totalElapsedMs = ((minutesSinceHour * 60) + secondsSinceminute) * 1000 + millisecondsSinceSecond;
    
    // Determine if pump should be on or off initially
    const isOn = totalElapsedMs < durationMs;
    
    // Calculate time until next state change
    let timeUntilChange;
    if (isOn) {
        timeUntilChange = durationMs - totalElapsedMs;
    } else {
        timeUntilChange = intervalMs - totalElapsedMs;
    }
    
    // Update UI
    updatePumpStatus(isOn);
    
    // Set timeout for the next state change
    setTimeout(() => {
        // Start the regular interval updates
        togglePumpState(interval, duration);
    }, timeUntilChange);
    
    // Calculate the last cycle time
    const lastCycleTime = new Date(now.getTime() - totalElapsedMs + (isOn ? 0 : durationMs));
    const timeStr = lastCycleTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    pumpTimeEl.textContent = `Last: ${timeStr}`;
    
    /**
     * Toggles pump state on regular intervals
     */
    function togglePumpState(interval, duration) {
        // Turn pump on
        updatePumpStatus(true);
        
        // Record the time
        const startTime = new Date();
        const timeStr = startTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        pumpTimeEl.textContent = `Started: ${timeStr}`;
        
        // Schedule turning it off
        setTimeout(() => {
            updatePumpStatus(false);
            
            // Schedule next pump cycle
            setTimeout(() => {
                togglePumpState(interval, duration);
            }, (interval - duration) * 60 * 1000);
            
        }, duration * 60 * 1000);
    }
    
    /**
     * Updates the UI to show current pump status
     */
    function updatePumpStatus(isOn) {
        const pumpBadgeEl = document.getElementById('pumpBadge');
        
        if (isOn) {
            pumpStatusEl.innerHTML = `
                <div class="spinner-grow spinner-grow-sm text-success" role="status">
                    <span class="visually-hidden">Running...</span>
                </div>
                <span class="ms-1 text-success small">Active</span>
            `;
            
            if (pumpBadgeEl) {
                pumpBadgeEl.className = 'badge bg-success';
                pumpBadgeEl.textContent = 'ON';
            }
        } else {
            pumpStatusEl.innerHTML = `
                <div class="spinner-grow spinner-grow-sm text-secondary" style="animation-duration: 2s;" role="status">
                    <span class="visually-hidden">Idle...</span>
                </div>
                <span class="ms-1 text-secondary small">Standby</span>
            `;
            
            if (pumpBadgeEl) {
                pumpBadgeEl.className = 'badge bg-secondary';
                pumpBadgeEl.textContent = 'OFF';
            }
        }
    }
}
