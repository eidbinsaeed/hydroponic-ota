/**
 * Real-time dashboard updates for the Hydroponic Farm Dashboard
 * This script fetches the latest readings via AJAX and updates the UI
 */

// Global variables for tracking changes
let lastPhLevel = null;
let lastWaterLevel = null;
let lastTimestamp = null;

// Refresh interval in milliseconds
const REFRESH_INTERVAL = 1000; // 1 second for Raspberry Pi with real sensors

/**
 * Initialize the real-time updates
 */
function initRealTimeUpdates() {
    // Fetch initial data to set the baseline
    fetchLatestReadings(true);
    
    // Set interval for regular updates
    setInterval(fetchLatestReadings, REFRESH_INTERVAL);
    
    // Log that real-time updates are active
    console.log('Real-time updates active. Refresh interval:', REFRESH_INTERVAL, 'ms');
}

/**
 * Fetch the latest readings from the API
 * @param {boolean} isInitial - Whether this is the initial fetch
 */
function fetchLatestReadings(isInitial = false) {
    fetch('/api/readings')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            updateDashboard(data, isInitial);
        })
        .catch(error => {
            console.error('Error fetching readings:', error);
            // Optionally show an error message on the dashboard
            document.querySelector('.fa-wifi').style.color = '#dc3545'; // Change WiFi icon to red
        });
}

/**
 * Update the dashboard elements with the latest readings
 * @param {Object} data - The latest readings data
 * @param {boolean} isInitial - Whether this is the initial update
 */
function updateDashboard(data, isInitial = false) {
    // Reset WiFi color if it was previously red
    document.querySelector('.fa-wifi').style.color = '#198754'; // Green
    
    // Update pH level display
    updatePhDisplay(data.ph_level, data.config.target_ph, isInitial);
    
    // Update water level display
    updateWaterDisplay(data.water_level, data.config.water_level_low, data.config.water_level_full, isInitial);
    
    // Update temperature and humidity display if elements exist
    updateClimateDisplay(
        data.temperature, 
        data.humidity, 
        data.config.min_temperature,
        data.config.max_temperature,
        data.config.min_humidity,
        data.config.max_humidity,
        isInitial
    );
    
    // Update air pump status if element exists
    updateAirPumpStatus(data.air_pump_state);
    
    // Update water pump status if element exists
    updateWaterPumpStatus(data.water_pump_state);
    
    // Update plant tower pump status if element exists
    updatePlantTowerPumpStatus(data.plant_tower_pump_state);
    
    // Update last refresh timestamp
    document.getElementById('lastUpdateTime').textContent = data.timestamp;
    
    // Blink the update indicator
    blinkUpdateIndicator();
    
    // Store current values for next comparison
    lastPhLevel = data.ph_level;
    lastWaterLevel = data.water_level;
    lastTemperature = data.temperature;
    lastHumidity = data.humidity;
    lastTimestamp = data.timestamp;
}

/**
 * Update the climate (temperature and humidity) displays with the latest readings
 * @param {number} temperature - Current temperature in Celsius
 * @param {number} humidity - Current humidity percentage
 * @param {number} minTemp - Minimum acceptable temperature
 * @param {number} maxTemp - Maximum acceptable temperature
 * @param {number} minHumidity - Minimum acceptable humidity
 * @param {number} maxHumidity - Maximum acceptable humidity
 * @param {boolean} isInitial - Whether this is the initial update
 */
function updateClimateDisplay(temperature, humidity, minTemp, maxTemp, minHumidity, maxHumidity, isInitial = false) {
    // Update temperature elements if they exist
    const tempValue = document.getElementById('tempValue');
    const tempBadge = document.getElementById('tempBadge');
    const tempStatus = document.getElementById('tempStatus');
    const tempProgressBar = document.getElementById('tempProgressBar');
    
    if (tempValue && tempBadge && tempStatus && tempProgressBar) {
        // Calculate if temperature is in range
        const tempInRange = temperature >= minTemp && temperature <= maxTemp;
        
        // Update the badge with new value and color
        tempBadge.textContent = `${temperature}°C`;
        tempBadge.className = `badge rounded-pill me-1 ${tempInRange ? 'bg-success' : 'bg-danger'}`;
        
        // Update the main temperature value with animation if not initial
        if (!isInitial && lastTemperature !== null && lastTemperature !== temperature) {
            // Add animation class based on whether temperature increased or decreased
            const animationClass = temperature > lastTemperature ? 'value-increased' : 'value-decreased';
            tempValue.textContent = `${temperature}°C`;
            tempValue.classList.add(animationClass);
            
            // Remove animation class after animation completes
            setTimeout(() => {
                tempValue.classList.remove(animationClass);
            }, 800);
        } else {
            tempValue.textContent = `${temperature}°C`;
        }
        
        // Update temperature status text
        if (temperature < minTemp) {
            tempStatus.innerHTML = '<span class="text-danger small">Too cold</span>';
        } else if (temperature > maxTemp) {
            tempStatus.innerHTML = '<span class="text-danger small">Too hot</span>';
        } else {
            tempStatus.innerHTML = '<span class="text-success small">Optimal</span>';
        }
        
        // Update progress bar
        const tempRange = maxTemp - minTemp;
        const tempPercent = ((temperature - minTemp) / tempRange) * 100;
        tempProgressBar.style.width = `${tempPercent}%`;
        tempProgressBar.className = `progress-bar ${tempInRange ? 'bg-success' : 'bg-danger'}`;
        tempProgressBar.setAttribute('aria-valuenow', temperature);
    }
    
    // Update humidity elements if they exist
    const humidityValue = document.getElementById('humidityValue');
    const humidityBadge = document.getElementById('humidityBadge');
    const humidityStatus = document.getElementById('humidityStatus');
    const humidityProgressBar = document.getElementById('humidityProgressBar');
    
    if (humidityValue && humidityBadge && humidityStatus && humidityProgressBar) {
        // Calculate if humidity is in range
        const humidityInRange = humidity >= minHumidity && humidity <= maxHumidity;
        
        // Update the badge with new value and color
        humidityBadge.textContent = `${humidity}%`;
        humidityBadge.className = `badge rounded-pill ${humidityInRange ? 'bg-info' : 'bg-warning'}`;
        
        // Update the main humidity value with animation if not initial
        if (!isInitial && lastHumidity !== null && lastHumidity !== humidity) {
            // Add animation class based on whether humidity increased or decreased
            const animationClass = humidity > lastHumidity ? 'value-increased' : 'value-decreased';
            humidityValue.textContent = `${humidity}%`;
            humidityValue.classList.add(animationClass);
            
            // Remove animation class after animation completes
            setTimeout(() => {
                humidityValue.classList.remove(animationClass);
            }, 800);
        } else {
            humidityValue.textContent = `${humidity}%`;
        }
        
        // Update humidity status text
        if (humidity < minHumidity) {
            humidityStatus.innerHTML = '<span class="text-warning small">Too dry</span>';
        } else if (humidity > maxHumidity) {
            humidityStatus.innerHTML = '<span class="text-warning small">Too humid</span>';
        } else {
            humidityStatus.innerHTML = '<span class="text-info small">Optimal</span>';
        }
        
        // Update progress bar
        const humidityRange = maxHumidity - minHumidity;
        const humidityPercent = ((humidity - minHumidity) / humidityRange) * 100;
        humidityProgressBar.style.width = `${humidityPercent}%`;
        humidityProgressBar.className = `progress-bar ${humidityInRange ? 'bg-info' : 'bg-warning'}`;
        humidityProgressBar.setAttribute('aria-valuenow', humidity);
    }
}

/**
 * Update the air pump status display
 * @param {boolean} isActive - Whether the air pump is currently active
 */
function updateAirPumpStatus(isActive) {
    // Check if air pump status elements exist
    const airPumpStatus = document.getElementById('airPumpStatus');
    const airPumpIcon = document.getElementById('airPumpIcon');
    
    if (airPumpStatus && airPumpIcon) {
        if (isActive) {
            airPumpStatus.innerHTML = '<span class="text-success">ON</span>';
            airPumpIcon.className = 'fas fa-wind text-success me-1 fa-pulse';
        } else {
            airPumpStatus.innerHTML = '<span class="text-secondary">OFF</span>';
            airPumpIcon.className = 'fas fa-wind text-secondary me-1';
        }
    }
    
    // Update additional air pump indicators if they exist
    const pumpIndicator = document.getElementById('pumpActiveIndicator');
    if (pumpIndicator) {
        if (isActive) {
            pumpIndicator.classList.add('active-indicator');
        } else {
            pumpIndicator.classList.remove('active-indicator');
        }
    }
}

/**
 * Update the water pump status display
 * @param {boolean} isActive - Whether the water pump is currently active
 */
function updateWaterPumpStatus(isActive) {
    // Check if water pump status elements exist
    const waterPumpStatus = document.getElementById('waterPumpStatus');
    const waterPumpIcon = document.getElementById('waterPumpIcon');
    const waterPumpBadge = document.getElementById('waterPumpBadge');
    
    if (waterPumpStatus) {
        if (isActive) {
            waterPumpStatus.innerHTML = '<span class="text-success">ON</span>';
            if (waterPumpIcon) {
                waterPumpIcon.className = 'fas fa-tint text-primary me-1 fa-pulse';
            }
            if (waterPumpBadge) {
                waterPumpBadge.className = 'badge bg-success';
                waterPumpBadge.textContent = 'Active';
            }
        } else {
            waterPumpStatus.innerHTML = '<span class="text-secondary">OFF</span>';
            if (waterPumpIcon) {
                waterPumpIcon.className = 'fas fa-tint text-secondary me-1';
            }
            if (waterPumpBadge) {
                waterPumpBadge.className = 'badge bg-secondary';
                waterPumpBadge.textContent = 'Idle';
            }
        }
    }
}

/**
 * Update the plant tower pump status display
 * @param {boolean} isActive - Whether the plant tower pump is currently active
 */
function updatePlantTowerPumpStatus(isActive) {
    // Check if plant tower pump status elements exist
    const plantTowerPumpStatus = document.getElementById('plantTowerPumpStatus');
    const plantTowerPumpIcon = document.getElementById('plantTowerPumpIcon');
    const plantTowerPumpBadge = document.getElementById('plantTowerPumpBadge');
    
    if (plantTowerPumpStatus) {
        if (isActive) {
            plantTowerPumpStatus.innerHTML = '<span class="text-success">ON</span>';
            if (plantTowerPumpIcon) {
                plantTowerPumpIcon.className = 'fas fa-seedling text-success me-1 fa-pulse';
            }
            if (plantTowerPumpBadge) {
                plantTowerPumpBadge.className = 'badge bg-success';
                plantTowerPumpBadge.textContent = 'Active';
            }
        } else {
            plantTowerPumpStatus.innerHTML = '<span class="text-secondary">OFF</span>';
            if (plantTowerPumpIcon) {
                plantTowerPumpIcon.className = 'fas fa-seedling text-secondary me-1';
            }
            if (plantTowerPumpBadge) {
                plantTowerPumpBadge.className = 'badge bg-secondary';
                plantTowerPumpBadge.textContent = 'Idle';
            }
        }
    }
}

/**
 * Update the pH level display with animation
 */
function updatePhDisplay(phLevel, targetPh, isInitial) {
    // Get all the elements we need to update
    const phValueDisplay = document.getElementById('phValue');
    const phProgressBar = document.getElementById('phProgressBar');
    const phStatusText = document.getElementById('phStatus');
    const phBadge = document.getElementById('phBadge');
    
    // Skip animation if this is the initial update
    if (isInitial) {
        updatePhElements(phValueDisplay, phProgressBar, phStatusText, phBadge, phLevel, targetPh);
        return;
    }
    
    // Calculate animation direction
    const direction = lastPhLevel !== null ? (phLevel > lastPhLevel ? 'up' : (phLevel < lastPhLevel ? 'down' : 'same')) : 'same';
    
    if (direction !== 'same') {
        // Add transition class based on direction
        phValueDisplay.classList.add(direction === 'up' ? 'value-increasing' : 'value-decreasing');
        
        // Remove the class after animation completes
        setTimeout(() => {
            phValueDisplay.classList.remove('value-increasing', 'value-decreasing');
        }, 800);
    }
    
    // Update the elements
    updatePhElements(phValueDisplay, phProgressBar, phStatusText, phBadge, phLevel, targetPh);
}

/**
 * Helper function to update all pH-related elements
 */
function updatePhElements(valueDisplay, progressBar, statusText, badge, phLevel, targetPh) {
    // Update the value display
    valueDisplay.textContent = phLevel;
    
    // Calculate progress bar percentage and color
    const phPercent = ((phLevel - 4) / 6) * 100;
    let phColor = "bg-danger";
    if (phLevel >= targetPh - 0.3 && phLevel <= targetPh + 0.3) {
        phColor = "bg-success";
    } else if (phLevel >= 5.5 && phLevel <= 7.5) {
        phColor = "bg-warning";
    }
    
    // Update progress bar
    progressBar.style.width = `${phPercent}%`;
    progressBar.className = `progress-bar progress-bar-striped ${phColor}`;
    progressBar.setAttribute('aria-valuenow', phLevel);
    progressBar.textContent = phLevel;
    
    // Update status text
    if (phLevel < targetPh - 0.3) {
        statusText.innerHTML = '<span class="text-warning small">Below target</span>';
    } else if (phLevel > targetPh + 0.3) {
        statusText.innerHTML = '<span class="text-warning small">Above target</span>';
    } else {
        statusText.innerHTML = '<span class="text-success small">In range</span>';
    }
    
    // Update badge
    badge.className = `badge rounded-pill ${phColor === "bg-success" ? "bg-success" : "bg-warning"}`;
    badge.textContent = phLevel;
}

/**
 * Update the water level display with animation
 */
function updateWaterDisplay(waterLevel, lowThreshold, fullThreshold, isInitial) {
    // Get all the elements we need to update
    const waterValueDisplay = document.getElementById('waterValue');
    const waterProgressBar = document.getElementById('waterProgressBar');
    const waterStatusText = document.getElementById('waterStatus');
    const waterBadge = document.getElementById('waterBadge');
    
    // Skip animation if this is the initial update
    if (isInitial) {
        updateWaterElements(waterValueDisplay, waterProgressBar, waterStatusText, waterBadge, waterLevel, lowThreshold, fullThreshold);
        return;
    }
    
    // Calculate animation direction
    const direction = lastWaterLevel !== null ? (waterLevel > lastWaterLevel ? 'up' : (waterLevel < lastWaterLevel ? 'down' : 'same')) : 'same';
    
    if (direction !== 'same') {
        // Add transition class based on direction
        waterValueDisplay.classList.add(direction === 'up' ? 'value-increasing' : 'value-decreasing');
        
        // Remove the class after animation completes
        setTimeout(() => {
            waterValueDisplay.classList.remove('value-increasing', 'value-decreasing');
        }, 800);
    }
    
    // Update the elements
    updateWaterElements(waterValueDisplay, waterProgressBar, waterStatusText, waterBadge, waterLevel, lowThreshold, fullThreshold);
}

/**
 * Helper function to update all water-related elements
 */
function updateWaterElements(valueDisplay, progressBar, statusText, badge, waterLevel, lowThreshold, fullThreshold) {
    // Update the value display
    valueDisplay.textContent = `${waterLevel}%`;
    
    // Calculate progress bar color
    let waterColor = "bg-danger";
    if (waterLevel >= lowThreshold && waterLevel <= fullThreshold) {
        waterColor = "bg-success";
    } else if (waterLevel > fullThreshold) {
        waterColor = "bg-info";
    }
    
    // Update progress bar
    progressBar.style.width = `${waterLevel}%`;
    progressBar.className = `progress-bar progress-bar-striped ${waterColor}`;
    progressBar.setAttribute('aria-valuenow', waterLevel);
    progressBar.textContent = `${waterLevel}%`;
    
    // Update status text
    if (waterLevel < lowThreshold) {
        statusText.innerHTML = '<span class="text-danger small">Too low</span>';
    } else if (waterLevel > fullThreshold) {
        statusText.innerHTML = '<span class="text-info small">Above full</span>';
    } else {
        statusText.innerHTML = '<span class="text-success small">Normal</span>';
    }
    
    // Update badge
    badge.className = `badge rounded-pill ${waterColor}`;
    badge.textContent = `${waterLevel}%`;
}

/**
 * Make the update indicator blink to show data refresh
 */
function blinkUpdateIndicator() {
    const indicator = document.getElementById('updateIndicator');
    
    // Add animation class
    indicator.classList.add('update-blink');
    
    // Remove class after animation completes
    setTimeout(() => {
        indicator.classList.remove('update-blink');
    }, 500);
}

// Initialize when the DOM is loaded
document.addEventListener('DOMContentLoaded', initRealTimeUpdates);