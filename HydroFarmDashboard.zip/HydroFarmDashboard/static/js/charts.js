/**
 * Initializes all charts for the reports page - optimized for 7" screen
 */
function initializeCharts(
    dailyTimestamps, dailyPhData, dailyWaterData,
    weeklyDays, weeklyPhData, weeklySolutionAData, weeklySolutionBData
) {
    // Set default Chart.js colors to better match our theme
    Chart.defaults.color = '#cbd5e0';
    Chart.defaults.borderColor = '#2d3748';
    Chart.defaults.font.size = 9;
    
    // Common options for small screen
    const smallScreenOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    boxWidth: 10,
                    padding: 4
                }
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                titleFont: {
                    size: 10
                },
                bodyFont: {
                    size: 10
                },
                padding: 5
            }
        },
        scales: {
            y: {
                ticks: {
                    padding: 0
                },
                grid: {
                    display: true,
                    drawBorder: true,
                    drawOnChartArea: true,
                    drawTicks: true
                }
            },
            x: {
                ticks: {
                    maxRotation: 0,
                    minRotation: 0,
                    autoSkip: true,
                    maxTicksLimit: 5
                },
                grid: {
                    display: false
                }
            }
        }
    };
    
    // Daily pH Chart
    const dailyPhChart = new Chart(
        document.getElementById('dailyPhChart'),
        {
            type: 'line',
            data: {
                labels: dailyTimestamps,
                datasets: [{
                    label: 'pH Level',
                    data: dailyPhData,
                    fill: false,
                    borderColor: '#4299e1',
                    tension: 0.1,
                    pointRadius: 1.5,
                    pointHoverRadius: 3,
                    borderWidth: 2
                }]
            },
            options: {
                ...smallScreenOptions,
                plugins: {
                    ...smallScreenOptions.plugins,
                    title: {
                        display: true,
                        text: 'pH Levels',
                        font: {
                            size: 10
                        },
                        padding: {
                            top: 1,
                            bottom: 3
                        }
                    }
                },
                scales: {
                    ...smallScreenOptions.scales,
                    y: {
                        ...smallScreenOptions.scales.y,
                        min: 4,
                        max: 8,
                        title: {
                            display: false
                        }
                    }
                }
            }
        }
    );
    
    // Daily Water Level Chart
    const dailyWaterChart = new Chart(
        document.getElementById('dailyWaterChart'),
        {
            type: 'line',
            data: {
                labels: dailyTimestamps,
                datasets: [{
                    label: 'Water Level',
                    data: dailyWaterData,
                    fill: true,
                    backgroundColor: 'rgba(72, 187, 120, 0.2)',
                    borderColor: '#48bb78',
                    tension: 0.1,
                    pointRadius: 1.5,
                    pointHoverRadius: 3,
                    borderWidth: 2
                }]
            },
            options: {
                ...smallScreenOptions,
                plugins: {
                    ...smallScreenOptions.plugins,
                    title: {
                        display: true,
                        text: 'Water Levels',
                        font: {
                            size: 10
                        },
                        padding: {
                            top: 1,
                            bottom: 3
                        }
                    }
                },
                scales: {
                    ...smallScreenOptions.scales,
                    y: {
                        ...smallScreenOptions.scales.y,
                        min: 0,
                        max: 100,
                        title: {
                            display: false
                        }
                    }
                }
            }
        }
    );
    
    // Weekly pH Chart
    const weeklyPhChart = new Chart(
        document.getElementById('weeklyPhChart'),
        {
            type: 'bar',
            data: {
                labels: weeklyDays,
                datasets: [{
                    label: 'Average pH',
                    data: weeklyPhData,
                    backgroundColor: '#4299e1',
                    borderColor: '#2b6cb0',
                    borderWidth: 1,
                    borderRadius: 2
                }]
            },
            options: {
                ...smallScreenOptions,
                plugins: {
                    ...smallScreenOptions.plugins,
                    title: {
                        display: true,
                        text: 'Weekly pH',
                        font: {
                            size: 10
                        },
                        padding: {
                            top: 1,
                            bottom: 3
                        }
                    }
                },
                scales: {
                    ...smallScreenOptions.scales,
                    y: {
                        ...smallScreenOptions.scales.y,
                        min: 4,
                        max: 8,
                        title: {
                            display: false
                        }
                    }
                }
            }
        }
    );
    
    // Weekly Solution Usage Chart
    const weeklySolutionChart = new Chart(
        document.getElementById('weeklySolutionChart'),
        {
            type: 'bar',
            data: {
                labels: weeklyDays,
                datasets: [
                    {
                        label: 'Solution A',
                        data: weeklySolutionAData,
                        backgroundColor: '#f56565',
                        borderColor: '#c53030',
                        borderWidth: 1,
                        borderRadius: 2
                    },
                    {
                        label: 'Solution B',
                        data: weeklySolutionBData,
                        backgroundColor: '#4c51bf',
                        borderColor: '#3c366b',
                        borderWidth: 1,
                        borderRadius: 2
                    }
                ]
            },
            options: {
                ...smallScreenOptions,
                plugins: {
                    ...smallScreenOptions.plugins,
                    title: {
                        display: true,
                        text: 'Solution Usage',
                        font: {
                            size: 10
                        },
                        padding: {
                            top: 1,
                            bottom: 3
                        }
                    }
                },
                scales: {
                    ...smallScreenOptions.scales,
                    y: {
                        ...smallScreenOptions.scales.y,
                        title: {
                            display: false
                        }
                    }
                }
            }
        }
    );
}

/**
 * Toggle between chart and table views for daily data
 */
function toggleDailyView(viewType) {
    const chartView = document.getElementById('daily-chart-view');
    const tableView = document.getElementById('daily-table-view');
    
    if (viewType === 'chart') {
        chartView.style.display = 'block';
        tableView.style.display = 'none';
    } else {
        chartView.style.display = 'none';
        tableView.style.display = 'block';
    }
}

/**
 * Toggle between chart and table views for weekly data
 */
function toggleWeeklyView(viewType) {
    const chartView = document.getElementById('weekly-chart-view');
    const tableView = document.getElementById('weekly-table-view');
    
    if (viewType === 'chart') {
        chartView.style.display = 'block';
        tableView.style.display = 'none';
    } else {
        chartView.style.display = 'none';
        tableView.style.display = 'block';
    }
}
