import os
import json
import random
import logging
import time
import threading
import io
import socket
import qrcode
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, Response, jsonify

# Import Wi-Fi manager for network configuration
from wifi_manager import wifi_manager

# Import sensor modules
from sensors import SensorManager
from sensors.gpio_controller import GPIOController

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "hydroponic-secret-key")

# Add template context processor for datetime functions
@app.context_processor
def utility_processor():
    return {'now': datetime.now}

# Default configuration
DEFAULT_CONFIG = {
    "water_level_low": 20,
    "water_level_full": 80,
    "target_ph": 6.0,
    "ph_check_interval": 30,
    "air_pump_interval": 60,
    "air_pump_duration": 15,
    "min_temperature": 18.0,
    "max_temperature": 30.0,
    "min_humidity": 30.0,
    "max_humidity": 80.0,
    "nutrient_a_ml_per_liter": 20.0,
    "nutrient_b_ml_per_liter": 30.0,
    "nutrient_a_flow_rate_ml_per_sec": 2.0,
    "nutrient_b_flow_rate_ml_per_sec": 2.0,
    "water_pump_flow_rate_lpm": 1.5,
    "plant_tower_pump_enabled": True,
    "plant_tower_pump_schedules": [
        {"start_time": "06:00", "end_time": "07:00", "enabled": True},
        {"start_time": "12:00", "end_time": "13:00", "enabled": True},
        {"start_time": "18:00", "end_time": "19:00", "enabled": True}
    ]
}

# Config file path
CONFIG_FILE = "config.json"

# Initialize sensor and GPIO management (at module level so it's accessible everywhere)
sensor_manager = SensorManager()
gpio_controller = GPIOController()

# Flag to track sensor initialization
sensors_initialized = False
gpio_initialized = False

# Initialize the sensors and GPIO
def initialize_hardware():
    global sensors_initialized, gpio_initialized
    
    # Initialize sensors if not already done
    if not sensors_initialized:
        logger.info("Initializing sensors...")
        sensors_initialized = sensor_manager.initialize_sensors()
        if sensors_initialized:
            logger.info("Sensors initialized successfully")
        else:
            logger.warning("Failed to initialize sensors, will use simulated data")
            
    # Initialize GPIO outputs if not already done
    if not gpio_initialized:
        logger.info("Initializing GPIO outputs...")
        gpio_initialized = gpio_controller.initialize_outputs()
        if gpio_initialized:
            logger.info("GPIO outputs initialized successfully")
        else:
            logger.warning("Failed to initialize GPIO outputs")
            
    return sensors_initialized, gpio_initialized

# Start the air pump automation in a background thread
def start_air_pump_automation():
    def air_pump_control_loop():
        logger.info("Starting air pump control loop")
        while True:
            try:
                # Get current config through local function
                try:
                    with open(CONFIG_FILE, "r") as f:
                        config = json.load(f)
                except Exception:
                    config = DEFAULT_CONFIG
                    
                interval = config.get("air_pump_interval", 60)
                duration = config.get("air_pump_duration", 15)
                
                # For testing/demo, use shorter times (seconds instead of minutes)
                interval_seconds = interval * 60  # Convert to seconds
                duration_seconds = duration * 60   # Convert to seconds
                
                # Debug with shorter times
                interval_seconds = 10  # Override to 10 seconds for testing
                duration_seconds = 5    # Override to 5 seconds for testing
                
                # Turn on air pump
                if gpio_initialized:
                    logger.info(f"Air pump turned ON for {duration_seconds} seconds")
                    # Directly set through dictionary to avoid GPIO errors in simulation
                    gpio_controller.outputs.get("air_pump", {})["current_state"] = True
                else:
                    logger.info("Air pump would turn on (simulation mode)")
                    
                # Wait for the duration
                time.sleep(duration_seconds)
                
                # Turn off air pump
                if gpio_initialized:
                    logger.info(f"Air pump turned OFF for {interval_seconds - duration_seconds} seconds")
                    # Directly set through dictionary to avoid GPIO errors in simulation
                    gpio_controller.outputs.get("air_pump", {})["current_state"] = False
                else:
                    logger.info("Air pump would turn off (simulation mode)")
                    
                # Wait until the next interval
                time.sleep(interval_seconds - duration_seconds)
                
            except Exception as e:
                logger.exception(f"Error in air pump control loop: {str(e)}")
                time.sleep(10)  # Wait and retry
    
    # Start the control loop in a separate thread
    thread = threading.Thread(target=air_pump_control_loop, daemon=True)
    thread.start()
    logger.info("Air pump automation thread started")

# Initialize hardware at startup
initialize_hardware()

# Plant tower pump automation
def start_plant_tower_pump_automation():
    def plant_tower_pump_control_loop():
        logger.info("Starting plant tower pump control loop")
        while True:
            try:
                # Get current config
                try:
                    with open(CONFIG_FILE, "r") as f:
                        config = json.load(f)
                except Exception:
                    config = DEFAULT_CONFIG

                # Check if pump scheduling is enabled
                if not config.get("plant_tower_pump_enabled", True):
                    # If not enabled, make sure pump is off and wait
                    if gpio_initialized and gpio_controller.get_output_state("plant_tower_pump"):
                        gpio_controller.set_output_state("plant_tower_pump", False)
                        logger.info("Plant tower pump disabled in settings, turning off")
                    time.sleep(30)  # Check again in 30 seconds
                    continue

                # Get current time
                now = datetime.now()
                current_time = now.strftime("%H:%M")
                
                # Get schedules
                schedules = config.get("plant_tower_pump_schedules", [])
                
                # Check if pump should be running based on schedules
                should_be_running = False
                for schedule in schedules:
                    if not schedule.get("enabled", True):
                        continue
                        
                    start_time = schedule.get("start_time", "")
                    end_time = schedule.get("end_time", "")
                    
                    if start_time <= current_time < end_time:
                        should_be_running = True
                        break
                
                # Control the pump based on schedule
                if gpio_initialized:
                    current_state = gpio_controller.get_output_state("plant_tower_pump")
                    
                    if should_be_running and not current_state:
                        logger.info(f"Plant tower pump turned ON (schedule: {current_time})")
                        gpio_controller.set_output_state("plant_tower_pump", True)
                    elif not should_be_running and current_state:
                        logger.info(f"Plant tower pump turned OFF (schedule: {current_time})")
                        gpio_controller.set_output_state("plant_tower_pump", False)
                
                # Check every minute
                time.sleep(60)
                
            except Exception as e:
                logger.exception(f"Error in plant tower pump control loop: {str(e)}")
                time.sleep(60)  # Wait and retry
    
    # Start the control loop in a separate thread
    thread = threading.Thread(target=plant_tower_pump_control_loop, daemon=True)
    thread.start()
    logger.info("Plant tower pump automation thread started")

# Start air pump automation
start_air_pump_automation()

# Start plant tower pump automation
start_plant_tower_pump_automation()

def load_config():
    """Load configuration from JSON file or create with defaults if not exists."""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                # Ensure new config values are present
                for key, value in DEFAULT_CONFIG.items():
                    if key not in config:
                        config[key] = value
                return config
        else:
            save_config(DEFAULT_CONFIG)
            return DEFAULT_CONFIG
    except Exception as e:
        logger.error(f"Error loading config: {e}")
        return DEFAULT_CONFIG

def save_config(config):
    """Save configuration to JSON file."""
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)
    except Exception as e:
        logger.error(f"Error saving config: {e}")

def get_current_readings():
    """Get current hydroponic system readings from real sensors or simulation."""
    config = load_config()
    readings = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "config": config
    }
    
    # If sensors are initialized, use real sensor data
    if sensors_initialized:
        logger.debug("Reading from real sensors")
        
        # Get the latest sensor readings
        sensor_data = sensor_manager.read_all_sensors()
        
        # Get pH level from sensor or use simulation if not available
        if "ph" in sensor_data and sensor_data["ph"] is not None:
            readings["ph_level"] = sensor_data["ph"]
        else:
            # Fallback to simulated pH
            readings["ph_level"] = round(random.uniform(
                config["target_ph"] - 0.5, 
                config["target_ph"] + 0.5
            ), 1)
            
        # Get water level from sensor or use simulation if not available
        if "water_level" in sensor_data and sensor_data["water_level"] is not None:
            readings["water_level"] = sensor_data["water_level"]
        else:
            # Fallback to simulated water level
            readings["water_level"] = random.randint(
                config["water_level_low"] - 10,
                config["water_level_full"] + 10
            )
            
        # Get temperature from sensor or use simulation if not available
        if "temperature" in sensor_data and sensor_data["temperature"] is not None:
            readings["temperature"] = sensor_data["temperature"]
        else:
            # Fallback to simulated temperature
            readings["temperature"] = round(random.uniform(
                config["min_temperature"] + 2.0,
                config["max_temperature"] - 2.0
            ), 1)
            
        # Get humidity from sensor or use simulation if not available
        if "humidity" in sensor_data and sensor_data["humidity"] is not None:
            readings["humidity"] = sensor_data["humidity"]
        else:
            # Fallback to simulated humidity
            readings["humidity"] = round(random.uniform(
                config["min_humidity"] + 5.0,
                config["max_humidity"] - 5.0
            ), 1)
    else:
        logger.debug("Using simulated sensor data")
        # Use simulation for all readings
        readings["ph_level"] = round(random.uniform(
            config["target_ph"] - 0.5, 
            config["target_ph"] + 0.5
        ), 1)
        
        readings["water_level"] = random.randint(
            config["water_level_low"] - 10,
            config["water_level_full"] + 10
        )
        
        # Simulated temperature
        readings["temperature"] = round(random.uniform(
            config["min_temperature"] + 2.0,
            config["max_temperature"] - 2.0
        ), 1)
        
        # Simulated humidity
        readings["humidity"] = round(random.uniform(
            config["min_humidity"] + 5.0,
            config["max_humidity"] - 5.0
        ), 1)
    
    # Get pump states if GPIO is initialized
    if gpio_initialized:
        readings["air_pump_state"] = gpio_controller.get_output_state("air_pump")
        readings["water_pump_state"] = gpio_controller.get_output_state("water_pump")
        readings["plant_tower_pump_state"] = gpio_controller.get_output_state("plant_tower_pump")
    else:
        readings["air_pump_state"] = False
        readings["water_pump_state"] = False
        readings["plant_tower_pump_state"] = False
    
    return readings

def generate_daily_report():
    """Generate simulated daily report data."""
    config = load_config()
    today = datetime.now()
    
    # Generate 24 hourly readings for the day
    hourly_data = []
    for hour in range(24):
        timestamp = today.replace(hour=hour, minute=0, second=0)
        # Simulate pH within +/- 0.8 of target with occasional outliers
        ph = round(random.uniform(
            config["target_ph"] - 0.8, 
            config["target_ph"] + 0.8
        ), 1)
        
        # Simulate water level decreasing over time with refills
        if hour % 8 == 0:  # Simulate refill every 8 hours
            water_level = random.randint(config["water_level_full"] - 10, config["water_level_full"] + 5)
        else:
            base = max(hourly_data[-1]["water_level"] - random.randint(1, 5), config["water_level_low"] - 5) if hourly_data else config["water_level_full"]
            water_level = base
        
        # Simulate solution usage
        solution_a = round(random.uniform(0.1, 0.5), 2)
        solution_b = round(random.uniform(0.1, 0.4), 2)
        
        hourly_data.append({
            "timestamp": timestamp.strftime("%H:00"),
            "ph": ph,
            "water_level": water_level,
            "solution_a": solution_a,
            "solution_b": solution_b
        })
    
    return hourly_data

def generate_weekly_report():
    """Generate simulated weekly report data."""
    config = load_config()
    today = datetime.now()
    
    # Generate data for the past 7 days
    daily_data = []
    for day_offset in range(7):
        day = today - timedelta(days=6-day_offset)
        
        # Simulate average pH for the day
        avg_ph = round(random.uniform(
            config["target_ph"] - 0.4, 
            config["target_ph"] + 0.4
        ), 1)
        
        # Simulate water usage for the day
        water_usage = round(random.uniform(2.0, 5.0), 1)
        
        # Simulate solution usage
        solution_a = round(random.uniform(0.8, 2.5), 2)
        solution_b = round(random.uniform(0.6, 2.0), 2)
        
        daily_data.append({
            "date": day.strftime("%Y-%m-%d"),
            "day": day.strftime("%a"),
            "avg_ph": avg_ph,
            "water_usage": water_usage,
            "solution_a": solution_a,
            "solution_b": solution_b
        })
    
    return daily_data

@app.route("/")
def home():
    """Display the home page with current readings."""
    readings = get_current_readings()
    config = load_config()
    return render_template("home.html", readings=readings, config=config)

@app.route("/api/readings", methods=["GET"])
def api_readings():
    """Return current readings as JSON for AJAX updates."""
    readings = get_current_readings()
    
    # Get additional sensor and GPIO status info
    sensor_statuses = {}
    if sensors_initialized:
        sensor_statuses = sensor_manager.get_sensor_statuses()
        
    gpio_statuses = {}
    if gpio_initialized:
        gpio_statuses = gpio_controller.get_output_statuses()
    
    return {
        "ph_level": readings["ph_level"],
        "water_level": readings["water_level"],
        "temperature": readings.get("temperature", 25.0),
        "humidity": readings.get("humidity", 50.0),
        "air_pump_state": readings.get("air_pump_state", False),
        "timestamp": readings["timestamp"],
        "config": {
            "water_level_low": readings["config"]["water_level_low"],
            "water_level_full": readings["config"]["water_level_full"],
            "target_ph": readings["config"]["target_ph"],
            "air_pump_interval": readings["config"]["air_pump_interval"],
            "air_pump_duration": readings["config"]["air_pump_duration"],
            "min_temperature": readings["config"].get("min_temperature", 18.0),
            "max_temperature": readings["config"].get("max_temperature", 30.0),
            "min_humidity": readings["config"].get("min_humidity", 30.0),
            "max_humidity": readings["config"].get("max_humidity", 80.0)
        },
        "sensor_status": {
            "initialized": sensors_initialized,
            "sensors": sensor_statuses
        },
        "gpio_status": {
            "initialized": gpio_initialized,
            "outputs": gpio_statuses
        }
    }

@app.route("/settings", methods=["GET", "POST"])
def settings():
    """Handle settings page - both display and save settings."""
    config = load_config()
    
    # Get sensor and GPIO configurations
    sensor_config = {}
    if os.path.exists(sensor_manager.SENSOR_CONFIG_FILE):
        try:
            with open(sensor_manager.SENSOR_CONFIG_FILE, "r") as f:
                sensor_config = json.load(f)
        except Exception as e:
            logger.error(f"Error loading sensor config: {str(e)}")
            
    gpio_config = {}
    if os.path.exists(gpio_controller.GPIO_CONFIG_FILE):
        try:
            with open(gpio_controller.GPIO_CONFIG_FILE, "r") as f:
                gpio_config = json.load(f)
        except Exception as e:
            logger.error(f"Error loading GPIO config: {str(e)}")
    
    if request.method == "POST":
        action = request.form.get("action", "update_system")
        
        if action == "update_system":
            try:
                # Update configuration from form data
                new_config = {
                    "water_level_low": int(request.form["water_level_low"]),
                    "water_level_full": int(request.form["water_level_full"]),
                    "target_ph": float(request.form["target_ph"]),
                    "ph_check_interval": int(request.form["ph_check_interval"]),
                    "air_pump_interval": int(request.form["air_pump_interval"]),
                    "air_pump_duration": int(request.form["air_pump_duration"]),
                    "min_temperature": float(request.form["min_temperature"]),
                    "max_temperature": float(request.form["max_temperature"]),
                    "min_humidity": float(request.form["min_humidity"]),
                    "max_humidity": float(request.form["max_humidity"]),
                    "nutrient_a_ml_per_liter": float(request.form["nutrient_a_ml_per_liter"]),
                    "nutrient_b_ml_per_liter": float(request.form["nutrient_b_ml_per_liter"]),
                    "nutrient_a_flow_rate_ml_per_sec": float(request.form["nutrient_a_flow_rate_ml_per_sec"]),
                    "nutrient_b_flow_rate_ml_per_sec": float(request.form["nutrient_b_flow_rate_ml_per_sec"]),
                    "water_pump_flow_rate_lpm": float(request.form["water_pump_flow_rate_lpm"]),
                    "plant_tower_pump_enabled": "plant_tower_pump_enabled" in request.form
                }
                
                # Process plant tower pump schedules
                schedule_starts = request.form.getlist("schedule_start[]")
                schedule_ends = request.form.getlist("schedule_end[]")
                schedule_enabled_values = request.form.getlist("schedule_enabled[]")
                
                # Create schedules list
                plant_tower_schedules = []
                for i in range(len(schedule_starts)):
                    if i < len(schedule_starts) and i < len(schedule_ends):
                        schedule = {
                            "start_time": schedule_starts[i],
                            "end_time": schedule_ends[i],
                            "enabled": str(i) in schedule_enabled_values
                        }
                        plant_tower_schedules.append(schedule)
                
                # Add schedules to config
                new_config["plant_tower_pump_schedules"] = plant_tower_schedules
                
                # Validate settings
                if new_config["water_level_low"] >= new_config["water_level_full"]:
                    flash("Error: Low water level must be less than full water level.", "danger")
                elif new_config["air_pump_duration"] > new_config["air_pump_interval"]:
                    flash("Error: Air pump duration must be less than or equal to interval.", "danger")
                elif new_config["min_temperature"] >= new_config["max_temperature"]:
                    flash("Error: Minimum temperature must be less than maximum temperature.", "danger")
                elif new_config["min_humidity"] >= new_config["max_humidity"]:
                    flash("Error: Minimum humidity must be less than maximum humidity.", "danger")
                else:
                    # Save valid configuration
                    save_config(new_config)
                    flash("System settings updated successfully!", "success")
                    return redirect(url_for("settings"))
                    
            except ValueError as e:
                flash(f"Error: Please check your input values. {str(e)}", "danger")
                
        elif action == "update_sensor":
            sensor_id = request.form.get("sensor_id", "")
            if sensor_id and sensor_id in sensor_config.get("sensors", {}):
                try:
                    sensor = sensor_config["sensors"][sensor_id]
                    
                    # Update enabled state
                    sensor["enabled"] = request.form.get("sensor_enabled") == "on"
                    
                    # Update sensor-specific settings
                    if sensor["type"] == "ph":
                        # Update pH calibration
                        if "calibration" not in sensor:
                            sensor["calibration"] = {}
                            
                        ph4_voltage = float(request.form.get("ph_4_voltage", 3.1))
                        ph7_voltage = float(request.form.get("ph_7_voltage", 2.5))
                        
                        sensor["calibration"]["ph_4_voltage"] = ph4_voltage
                        sensor["calibration"]["ph_7_voltage"] = ph7_voltage
                        
                        # Apply calibration if sensor is active
                        if sensors_initialized and "ph" in sensor_manager.sensors:
                            sensor_manager.calibrate_sensor("ph", {
                                "ph_4_voltage": ph4_voltage,
                                "ph_7_voltage": ph7_voltage
                            })
                    
                    elif sensor["type"] == "water_level":
                        # Update water level calibration
                        tank_height = float(request.form.get("tank_height_cm", 30.0))
                        empty_distance = float(request.form.get("tank_empty_distance", 25.0))
                        full_distance = float(request.form.get("tank_full_distance", 5.0))
                        
                        sensor["tank_height_cm"] = tank_height
                        sensor["tank_empty_distance"] = empty_distance
                        sensor["tank_full_distance"] = full_distance
                        
                        # Apply calibration if sensor is active
                        if sensors_initialized and "water_level" in sensor_manager.sensors:
                            sensor_manager.calibrate_sensor("water_level", {
                                "tank_empty_distance": empty_distance,
                                "tank_full_distance": full_distance
                            })
                    
                    # Save updated sensor config
                    with open(sensor_manager.SENSOR_CONFIG_FILE, "w") as f:
                        json.dump(sensor_config, f, indent=4)
                    
                    # Re-initialize the sensors
                    sensor_manager.config = sensor_config
                    sensor_manager.initialize_sensors()
                    
                    flash(f"Sensor {sensor_id} settings updated successfully!", "success")
                    return redirect(url_for("settings"))
                    
                except (ValueError, KeyError) as e:
                    flash(f"Error updating sensor settings: {str(e)}", "danger")
            else:
                flash("Invalid sensor selected", "danger")
                
        elif action == "update_gpio":
            output_id = request.form.get("output_id", "")
            if output_id and output_id in gpio_config.get("outputs", {}):
                try:
                    output = gpio_config["outputs"][output_id]
                    
                    # Update output settings
                    output["enabled"] = request.form.get("output_enabled") == "on"
                    output["pin"] = int(request.form.get("pin", 0))
                    output["active_low"] = request.form.get("active_low") == "on"
                    output["default_state"] = request.form.get("default_state", "off")
                    output["description"] = request.form.get("description", "")
                    
                    # Save updated GPIO config
                    with open(gpio_controller.GPIO_CONFIG_FILE, "w") as f:
                        json.dump(gpio_config, f, indent=4)
                    
                    # Re-initialize the GPIO outputs
                    gpio_controller.config = gpio_config
                    gpio_controller.initialize_outputs()
                    
                    flash(f"Output {output_id} settings updated successfully!", "success")
                    return redirect(url_for("settings"))
                    
                except (ValueError, KeyError) as e:
                    flash(f"Error updating output settings: {str(e)}", "danger")
            else:
                flash("Invalid output selected", "danger")
                
        elif action == "control_output":
            output_id = request.form.get("control_output_id", "")
            command = request.form.get("command", "")
            
            if output_id and command and gpio_initialized:
                try:
                    duration_str = request.form.get("duration", "")
                    
                    if command == "on":
                        if duration_str and duration_str.isdigit():
                            # Turn on with timer
                            duration = int(duration_str)
                            gpio_controller.set_output_with_timer(output_id, True, duration)
                            flash(f"Output {output_id} turned ON for {duration} seconds", "success")
                        else:
                            # Turn on indefinitely
                            gpio_controller.set_output_state(output_id, True)
                            flash(f"Output {output_id} turned ON", "success")
                    elif command == "off":
                        gpio_controller.set_output_state(output_id, False)
                        flash(f"Output {output_id} turned OFF", "success")
                    elif command == "toggle":
                        gpio_controller.toggle_output(output_id)
                        current_state = "ON" if gpio_controller.get_output_state(output_id) else "OFF"
                        flash(f"Output {output_id} toggled to {current_state}", "success")
                    
                    return redirect(url_for("settings"))
                
                except Exception as e:
                    flash(f"Error controlling output: {str(e)}", "danger")
            else:
                flash("Invalid output control command", "danger")
    
    # Get current status information
    sensor_statuses = {}
    if sensors_initialized:
        sensor_statuses = sensor_manager.get_sensor_statuses()
        
    gpio_statuses = {}
    if gpio_initialized:
        gpio_statuses = gpio_controller.get_output_statuses()
    
    return render_template(
        "settings.html",
        config=config,
        sensor_config=sensor_config,
        gpio_config=gpio_config,
        sensor_statuses=sensor_statuses,
        gpio_statuses=gpio_statuses,
        sensors_initialized=sensors_initialized,
        gpio_initialized=gpio_initialized
    )

@app.route("/reports")
def reports():
    """Display system reports."""
    daily_data = generate_daily_report()
    weekly_data = generate_weekly_report()
    
    # Calculate summary statistics for reports
    weekly_summary = {
        "avg_ph": round(sum(day["avg_ph"] for day in weekly_data) / len(weekly_data), 1),
        "total_water": round(sum(day["water_usage"] for day in weekly_data), 1),
        "total_solution_a": round(sum(day["solution_a"] for day in weekly_data), 2),
        "total_solution_b": round(sum(day["solution_b"] for day in weekly_data), 2)
    }
    
    return render_template(
        "reports.html", 
        daily_data=daily_data, 
        weekly_data=weekly_data, 
        weekly_summary=weekly_summary
    )

def get_local_ip():
    """Get the local IP address of the Raspberry Pi."""
    try:
        # Create a socket connection to determine the local IP address
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Doesn't need to be reachable, just allows socket to determine default route
        s.connect(('8.8.8.8', 1))  
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except Exception as e:
        logger.error(f"Error getting local IP: {e}")
        return "127.0.0.1"  # Fallback to localhost

@app.route("/api/local_ip")
def get_local_ip_api():
    """Return the local IP address as JSON."""
    local_ip = get_local_ip()
    port = request.environ.get('SERVER_PORT', 5000)
    url = f"http://{local_ip}:{port}"
    return {"ip": local_ip, "url": url}

@app.route("/qr")
def generate_qr():
    """Generate and return a QR code image for the local IP address."""
    local_ip = get_local_ip()
    port = request.environ.get('SERVER_PORT', 5000)
    url = f"http://{local_ip}:{port}"
    
    # Create QR code instance with error correction
    qr = qrcode.make(url)
    
    # Save the image to a bytes buffer
    img_buffer = io.BytesIO()
    qr.save(img_buffer, format='PNG')
    img_buffer.seek(0)
    
    # Return the image as a response
    return Response(img_buffer.getvalue(), mimetype='image/png')

# Wi-Fi management routes
@app.route("/api/wifi/scan")
def wifi_scan():
    """Scan for available Wi-Fi networks and return as JSON."""
    networks = wifi_manager.scan_networks()
    return jsonify({
        "networks": networks,
        "nmcli_available": wifi_manager.is_nmcli_available()
    })

@app.route("/api/wifi/status")
def wifi_status():
    """Get current Wi-Fi connection status as JSON."""
    status = wifi_manager.get_connection_status()
    return jsonify(status)

@app.route("/api/wifi/connect", methods=["POST"])
def wifi_connect():
    """Connect to a Wi-Fi network."""
    data = request.json
    if not data or "ssid" not in data:
        return jsonify({"success": False, "message": "SSID is required"}), 400
    
    ssid = data["ssid"]
    password = data.get("password", None)  # Password might be optional for open networks
    
    success, message = wifi_manager.connect_to_network(ssid, password)
    return jsonify({"success": success, "message": message})

@app.route("/api/wifi/disconnect", methods=["POST"])
def wifi_disconnect():
    """Disconnect from current Wi-Fi network."""
    success, message = wifi_manager.disconnect()
    return jsonify({"success": success, "message": message})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
