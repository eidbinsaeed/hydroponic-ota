"""
Abstract base class for sensors in the Hydroponic Farm Dashboard.
This provides a common interface for different sensor types.
"""

import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, Tuple
import time

# Setup logging
logger = logging.getLogger(__name__)

class SensorInterface(ABC):
    """Base interface that all sensors should implement."""
    
    def __init__(
        self, 
        name: str, 
        sensor_type: str, 
        pin: Optional[int] = None, 
        channel: Optional[int] = None,
        port: Optional[str] = None,
        i2c_address: Optional[int] = None,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize a sensor with common parameters.
        
        Args:
            name: Human-readable name for this sensor
            sensor_type: Type of sensor (e.g., 'ph', 'water_level')
            pin: GPIO pin number if using direct GPIO
            channel: ADC channel number if using an ADC
            port: Serial port path if using serial communication
            i2c_address: I2C address if using I2C communication
            config: Additional sensor-specific configuration
        """
        self.name = name
        self.sensor_type = sensor_type
        self.pin = pin
        self.channel = channel
        self.port = port
        self.i2c_address = i2c_address
        self.config = config or {}
        self.connected = False
        self.last_reading = None
        self.last_reading_time = 0
        self.error_count = 0
        self.max_errors = 5
        self.calibration_data = {}
        
        # Initialize the sensor
        self.setup()
    
    @abstractmethod
    def setup(self) -> bool:
        """
        Set up the sensor hardware connection.
        Returns True if setup successful, False otherwise.
        """
        pass
    
    @abstractmethod
    def read_raw(self) -> Any:
        """
        Read raw data from the sensor.
        Returns the raw sensor value.
        """
        pass
    
    @abstractmethod
    def convert_reading(self, raw_value: Any) -> float:
        """
        Convert raw sensor data to meaningful value.
        
        Args:
            raw_value: The raw value from read_raw()
            
        Returns:
            The converted, calibrated value
        """
        pass
    
    def read(self) -> Tuple[float, bool]:
        """
        Read and process sensor data, with error handling.
        
        Returns:
            Tuple of (reading value, success flag)
        """
        try:
            if not self.connected:
                if not self.setup():
                    self.error_count += 1
                    logger.error(f"Failed to set up sensor: {self.name}")
                    return None, False
            
            raw_data = self.read_raw()
            if raw_data is None:
                self.error_count += 1
                logger.warning(f"Failed to read from sensor: {self.name}")
                return None, False
                
            reading = self.convert_reading(raw_data)
            self.last_reading = reading
            self.last_reading_time = time.time()
            self.error_count = 0
            return reading, True
            
        except Exception as e:
            self.error_count += 1
            logger.exception(f"Error reading from sensor {self.name}: {str(e)}")
            
            # If too many errors, try to re-initialize
            if self.error_count >= self.max_errors:
                logger.warning(f"Too many errors from sensor {self.name}, attempting reconnection")
                self.setup()
                
            return None, False
    
    def calibrate(self, reference_points: List[Tuple[float, float]]) -> bool:
        """
        Calibrate the sensor using reference measurements.
        
        Args:
            reference_points: List of (raw_value, calibrated_value) pairs
            
        Returns:
            True if calibration successful, False otherwise
        """
        # Basic calibration - can be overridden by specific sensors
        if len(reference_points) < 2:
            logger.error("Need at least two points for calibration")
            return False
            
        try:
            # Store calibration data
            self.calibration_data['points'] = reference_points
            
            # Sort by raw values
            sorted_points = sorted(reference_points, key=lambda x: x[0])
            
            # Extract x and y points
            x_points = [point[0] for point in sorted_points]
            y_points = [point[1] for point in sorted_points]
            
            # Calculate slope and intercept (linear fit)
            n = len(reference_points)
            sum_x = sum(x_points)
            sum_y = sum(y_points)
            sum_xy = sum(x * y for x, y in zip(x_points, y_points))
            sum_xx = sum(x * x for x in x_points)
            
            slope = (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x * sum_x)
            intercept = (sum_y - slope * sum_x) / n
            
            self.calibration_data['slope'] = slope
            self.calibration_data['intercept'] = intercept
            
            logger.info(f"Calibrated sensor {self.name}: y = {slope:.4f}x + {intercept:.4f}")
            return True
            
        except Exception as e:
            logger.exception(f"Error calibrating sensor {self.name}: {str(e)}")
            return False
    
    def apply_calibration(self, raw_value: float) -> float:
        """
        Apply calibration to a raw sensor value.
        
        Args:
            raw_value: The raw sensor reading
            
        Returns:
            Calibrated value
        """
        if not self.calibration_data or 'slope' not in self.calibration_data:
            return raw_value
            
        slope = self.calibration_data['slope']
        intercept = self.calibration_data['intercept']
        return slope * raw_value + intercept
        
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of the sensor.
        
        Returns:
            Dict with sensor status information
        """
        return {
            'name': self.name,
            'type': self.sensor_type,
            'connected': self.connected,
            'last_reading': self.last_reading,
            'last_reading_time': self.last_reading_time,
            'error_count': self.error_count
        }