"""
GPIO controller for the Hydroponic Farm Dashboard.
Handles relay control for pumps, lights, and other actuators.
"""

import logging
import time
import json
import os
import threading
from typing import Dict, List, Any, Optional, Tuple

try:
    import RPi.GPIO as GPIO
    HARDWARE_AVAILABLE = True
except (ImportError, RuntimeError):
    HARDWARE_AVAILABLE = False

# Setup logging
logger = logging.getLogger(__name__)

class GPIOController:
    """Controller class for GPIO outputs like relays, LEDs, etc."""
    
    # Nutrient dosing parameters
    NUTRIENT_A_RATE_ML_PER_SEC = 2.0  # 2ml per second flow rate
    NUTRIENT_B_RATE_ML_PER_SEC = 2.0
    WATER_PUMP_RATE_L_PER_MIN = 2.0    # 2L per minute
    NUTRIENT_A_RATIO_ML_PER_L = 20.0   # 20ml per liter
    NUTRIENT_B_RATIO_ML_PER_L = 30.0   # 30ml per liter
    
    # File to store output configurations
    GPIO_CONFIG_FILE = "gpio_config.json"
    
    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the GPIO controller.
        
        Args:
            config_file: Path to configuration file (default: gpio_config.json)
        """
        self.outputs: Dict[str, Dict[str, Any]] = {}
        self.config_file = config_file or self.GPIO_CONFIG_FILE
        self.config = self._load_config()
        self.output_timers: Dict[str, threading.Timer] = {}
        self.app_config_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
        
        # Initialize GPIO if available
        if HARDWARE_AVAILABLE:
            GPIO.setwarnings(False)
            GPIO.setmode(GPIO.BCM)
            logger.info("GPIO controller initialized in BCM mode")
        else:
            logger.warning("GPIO library not available, using simulation mode")
    
    def _get_app_config_value(self, key: str, default_value: Any) -> Any:
        """
        Get a value from the application configuration file.
        
        Args:
            key: Configuration key to retrieve
            default_value: Default value to return if not found
            
        Returns:
            The configuration value if found, otherwise the default value
        """
        try:
            if os.path.exists(self.app_config_file):
                with open(self.app_config_file, 'r') as f:
                    config = json.load(f)
                if key in config:
                    return config[key]
        except Exception as e:
            logger.error(f"Error reading application configuration: {str(e)}")
        return default_value
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Load GPIO configuration from file or create with defaults.
        
        Returns:
            Dict containing GPIO configurations
        """
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                logger.info(f"Loaded GPIO configuration from {self.config_file}")
                return config
            except Exception as e:
                logger.error(f"Error loading GPIO configuration: {str(e)}")
                return self._get_default_config()
        else:
            # Create default config
            config = self._get_default_config()
            self._save_config(config)
            return config
    
    def _save_config(self, config: Dict[str, Any]) -> bool:
        """
        Save GPIO configuration to file.
        
        Args:
            config: Configuration dictionary to save
            
        Returns:
            True if saved successfully, False otherwise
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            logger.info(f"Saved GPIO configuration to {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"Error saving GPIO configuration: {str(e)}")
            return False
    
    def _get_default_config(self) -> Dict[str, Any]:
        """
        Get default GPIO configuration.
        
        Returns:
            Dict with default GPIO configurations
        """
        return {
            "outputs": {
                "air_pump": {
                    "enabled": True,
                    "type": "relay",
                    "pin": 26,
                    "active_low": True,  # Most relays are active low (LOW turns relay ON)
                    "default_state": "off",
                    "description": "Air pump for oxygenating water"
                },
                "water_pump": {
                    "enabled": True,
                    "type": "relay",
                    "pin": 20,
                    "active_low": True,
                    "default_state": "off",
                    "description": "Tank water pump"
                },
                "nutrient_pump_a": {
                    "enabled": True,
                    "type": "relay",
                    "pin": 21,
                    "active_low": True,
                    "default_state": "off",
                    "description": "Nutrient solution A dosing pump"
                }
            }
        }
    
    def initialize_outputs(self) -> bool:
        """
        Initialize all outputs based on configuration.
        
        Returns:
            True if any outputs were successfully initialized
        """
        if not self.config or "outputs" not in self.config:
            logger.error("No valid GPIO configuration found")
            return False
            
        success = False
        
        # Clear existing outputs and timers
        self.outputs = {}
        for timer in self.output_timers.values():
            if timer.is_alive():
                timer.cancel()
        self.output_timers = {}
        
        # Initialize each configured output
        for output_id, output_config in self.config["outputs"].items():
            if not output_config.get("enabled", True):
                logger.info(f"Skipping disabled output: {output_id}")
                continue
                
            try:
                pin = output_config.get("pin")
                if pin is None:
                    logger.error(f"No pin specified for output: {output_id}")
                    continue
                    
                # Store output configuration
                self.outputs[output_id] = output_config
                
                # Set up GPIO pin
                if HARDWARE_AVAILABLE:
                    GPIO.setup(pin, GPIO.OUT)
                    
                    # Set to default state
                    default_state = output_config.get("default_state", "off").lower()
                    self.set_output_state(output_id, default_state == "on")
                    
                logger.info(f"Successfully initialized output: {output_id} on pin {pin}")
                success = True
                
            except Exception as e:
                logger.exception(f"Error initializing output {output_id}: {str(e)}")
        
        return success
    
    def set_output_state(self, output_id: str, state: bool) -> bool:
        """
        Set the state of an output.
        
        Args:
            output_id: ID of the output to control
            state: True for on, False for off
            
        Returns:
            True if successful, False otherwise
        """
        if output_id not in self.outputs:
            logger.error(f"Output {output_id} not found")
            return False
            
        output = self.outputs[output_id]
        pin = output.get("pin")
        active_low = output.get("active_low", False)
        
        # Determine GPIO value based on active_low setting
        gpio_value = GPIO.LOW if (state and not active_low) or (not state and active_low) else GPIO.HIGH
        
        try:
            if HARDWARE_AVAILABLE:
                GPIO.output(pin, gpio_value)
                
            # Update output state in configuration
            self.outputs[output_id]["current_state"] = state
            
            logger.info(f"Set output {output_id} to {'ON' if state else 'OFF'}")
            return True
            
        except Exception as e:
            logger.exception(f"Error setting output {output_id} state: {str(e)}")
            return False
    
    def get_output_state(self, output_id: str) -> bool:
        """
        Get the current state of an output.
        
        Args:
            output_id: ID of the output to check
            
        Returns:
            True if on, False if off
        """
        if output_id not in self.outputs:
            logger.error(f"Output {output_id} not found")
            return False
        
        # Get from stored state if not in hardware mode
        if not HARDWARE_AVAILABLE:
            return self.outputs[output_id].get("current_state", False)
            
        # Otherwise, read from GPIO
        try:
            pin = self.outputs[output_id].get("pin")
            active_low = self.outputs[output_id].get("active_low", False)
            
            gpio_value = GPIO.input(pin)
            state = (gpio_value == GPIO.LOW) if active_low else (gpio_value == GPIO.HIGH)
            
            return state
            
        except Exception as e:
            logger.exception(f"Error reading output {output_id} state: {str(e)}")
            return False
    
    def toggle_output(self, output_id: str) -> bool:
        """
        Toggle the state of an output.
        
        Args:
            output_id: ID of the output to toggle
            
        Returns:
            True if successful, False otherwise
        """
        current_state = self.get_output_state(output_id)
        return self.set_output_state(output_id, not current_state)
    
    def set_output_with_timer(self, output_id: str, state: bool, duration_seconds: float) -> bool:
        """
        Set an output state with an automatic timer to revert after duration.
        
        Args:
            output_id: ID of the output to control
            state: True for on, False for off
            duration_seconds: Time in seconds before reverting to opposite state
            
        Returns:
            True if successful, False otherwise
        """
        # Cancel any existing timer for this output
        if output_id in self.output_timers and self.output_timers[output_id].is_alive():
            self.output_timers[output_id].cancel()
            
        # Set the initial state
        if not self.set_output_state(output_id, state):
            return False
            
        # Create a timer to revert the state after duration
        timer = threading.Timer(
            duration_seconds,
            lambda: self.set_output_state(output_id, not state)
        )
        timer.daemon = True
        timer.start()
        
        # Store the timer
        self.output_timers[output_id] = timer
        
        logger.info(f"Set {output_id} to {'ON' if state else 'OFF'} for {duration_seconds} seconds")
        return True
    
    def pulse_output(self, output_id: str, duration_seconds: float) -> bool:
        """
        Turn an output on for a specified duration then off.
        
        Args:
            output_id: ID of the output to pulse
            duration_seconds: Duration in seconds for the pulse
            
        Returns:
            True if successful, False otherwise
        """
        return self.set_output_with_timer(output_id, True, duration_seconds)
    
    def get_output_ids(self) -> List[str]:
        """
        Get list of all output IDs.
        
        Returns:
            List of output IDs
        """
        return list(self.outputs.keys())
    
    def get_output_statuses(self) -> Dict[str, Dict[str, Any]]:
        """
        Get status information for all outputs.
        
        Returns:
            Dict with status info for each output
        """
        statuses = {}
        
        for output_id, output in self.outputs.items():
            statuses[output_id] = {
                "id": output_id,
                "pin": output.get("pin"),
                "type": output.get("type", "relay"),
                "description": output.get("description", ""),
                "state": self.get_output_state(output_id),
                "has_timer": output_id in self.output_timers and self.output_timers[output_id].is_alive()
            }
            
        return statuses
    
    def dose_nutrients_for_volume(self, water_volume_liters: float) -> None:
        """
        Dose nutrients A and B based on water volume being added.
        
        Args:
            water_volume_liters: Volume of water being added in liters
        """
        # Get nutrient dosing values from configuration
        nutrient_a_ratio = self._get_app_config_value("nutrient_a_ml_per_liter", self.NUTRIENT_A_RATIO_ML_PER_L)
        nutrient_b_ratio = self._get_app_config_value("nutrient_b_ml_per_liter", self.NUTRIENT_B_RATIO_ML_PER_L)
        
        # Get nutrient pump flow rates from configuration
        nutrient_a_flow_rate = self._get_app_config_value("nutrient_a_flow_rate_ml_per_sec", self.NUTRIENT_A_RATE_ML_PER_SEC)
        nutrient_b_flow_rate = self._get_app_config_value("nutrient_b_flow_rate_ml_per_sec", self.NUTRIENT_B_RATE_ML_PER_SEC)
        
        logger.info(f"Using nutrient dosing ratios: A={nutrient_a_ratio}mL/L, B={nutrient_b_ratio}mL/L")
        logger.info(f"Using pump flow rates: A={nutrient_a_flow_rate}mL/sec, B={nutrient_b_flow_rate}mL/sec")
        
        # Calculate required nutrient volumes
        nutrient_a_ml = water_volume_liters * nutrient_a_ratio
        nutrient_b_ml = water_volume_liters * nutrient_b_ratio
        
        # Calculate required pump run times
        nutrient_a_seconds = nutrient_a_ml / nutrient_a_flow_rate
        nutrient_b_seconds = nutrient_b_ml / nutrient_b_flow_rate
        
        logger.info(f"Dosing nutrients for {water_volume_liters}L water:")
        logger.info(f"Nutrient A: {nutrient_a_ml}ml ({nutrient_a_seconds:.1f}s)")
        logger.info(f"Nutrient B: {nutrient_b_ml}ml ({nutrient_b_seconds:.1f}s)")
        
        # Run nutrient pumps for calculated durations
        self.set_output_with_timer("nutrient_pump_a", True, nutrient_a_seconds)
        time.sleep(1)  # Small delay between nutrients
        self.set_output_with_timer("nutrient_pump_b", True, nutrient_b_seconds)
    
    def refill_tank(self, target_level: int) -> None:
        """
        Refill tank to target level and add appropriate nutrients.
        
        Args:
            target_level: Target water level percentage
        """
        # Get water pump flow rate from configuration
        water_pump_flow_rate = self._get_app_config_value("water_pump_flow_rate_lpm", self.WATER_PUMP_RATE_L_PER_MIN)
        logger.info(f"Using tank water pump flow rate: {water_pump_flow_rate}L/min")
        
        if not self.get_output_state("water_pump"):
            current_level = 0  # You should get this from your sensor
            liters_needed = (target_level - current_level) * 0.01 * 50  # Assume 50L tank capacity
            
            if liters_needed > 0:
                # Start tank water pump
                minutes_needed = liters_needed / water_pump_flow_rate
                seconds_needed = minutes_needed * 60
                
                logger.info(f"Refilling tank with {liters_needed:.1f}L water ({seconds_needed:.1f}s) at {water_pump_flow_rate}L/min")
                # Activate the tank water pump for calculated time
                self.set_output_with_timer("water_pump", True, seconds_needed)
                
                # Add nutrients after slight delay to let water start flowing
                time.sleep(2)
                self.dose_nutrients_for_volume(liters_needed)

    def cleanup(self):
        """Clean up GPIO resources when done."""
        # Cancel all timers
        for timer in self.output_timers.values():
            if timer.is_alive():
                timer.cancel()
                
        # Reset GPIO if in hardware mode
        if HARDWARE_AVAILABLE:
            GPIO.cleanup()
            
        logger.info("GPIO controller resources cleaned up")