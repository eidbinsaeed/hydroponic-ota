"""
Sensor module for the Hydroponic Farm Dashboard.
This package provides interfaces and implementations for various sensors.
"""

# Import specific sensor types
from .sensor_interface import SensorInterface
from .ph_sensor import PHSensor
from .water_level_sensor import WaterLevelSensor
from .climate_sensor import ClimateSensor

# Direct import of the sensor manager for ease of use
from .sensor_manager import SensorManager

__all__ = [
    'SensorInterface',
    'PHSensor',
    'WaterLevelSensor',
    'ClimateSensor',
    'SensorManager',
]