"""
Water level sensor implementation for the Hydroponic Farm Dashboard.
Supports ultrasonic sensors, float switches, and capacitive sensors.
"""

import logging
import time
from typing import Dict, Any, Optional, Union, List
import serial

try:
    import busio
    import board
    import RPi.GPIO as GPIO
    from adafruit_ads1x15.ads1x15 import ADS
    from adafruit_ads1x15.analog_in import AnalogIn
    import adafruit_ads1x15.ads1115 as ADS1115
    import adafruit_ads1x15.ads1015 as ADS1015
    HARDWARE_AVAILABLE = True
except (ImportError, RuntimeError):
    HARDWARE_AVAILABLE = False

from .sensor_interface import SensorInterface

# Setup logging
logger = logging.getLogger(__name__)

class WaterLevelSensor(SensorInterface):
    """Water level sensor implementation supporting various sensor types."""
    
    # Constants for ultrasonic sensors
    SPEED_OF_SOUND = 34300  # cm/s at 20°C
    
    def __init__(
        self,
        name: str = "Water Level Sensor",
        sensor_subtype: str = "ultrasonic",  # 'ultrasonic', 'float', 'capacitive', 'pressure'
        pin: Optional[int] = None,
        trigger_pin: Optional[int] = None,  # For ultrasonic sensors
        echo_pin: Optional[int] = None,     # For ultrasonic sensors
        float_pins: Optional[List[int]] = None,  # For float switch arrays
        channel: Optional[int] = 0,
        port: Optional[str] = None,
        i2c_address: Optional[int] = 0x48,
        tank_height_cm: float = 30.0,  # Height of the tank in cm
        tank_empty_distance: float = 25.0,  # Distance reading when tank is empty
        tank_full_distance: float = 5.0,    # Distance reading when tank is full
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize a water level sensor with hardware configuration.
        
        Args:
            name: Human-readable name for this sensor
            sensor_subtype: Type of water level sensor
            pin: GPIO pin for simple sensors
            trigger_pin: GPIO pin for ultrasonic trigger
            echo_pin: GPIO pin for ultrasonic echo
            float_pins: List of GPIO pins for float switch array
            channel: ADC channel for analog sensors
            port: Serial port for serial sensors
            i2c_address: I2C address of ADC
            tank_height_cm: Height of water tank in centimeters
            tank_empty_distance: Sensor reading (distance) when tank is empty
            tank_full_distance: Sensor reading (distance) when tank is full
            config: Additional configuration parameters
        """
        self.sensor_subtype = sensor_subtype
        self.trigger_pin = trigger_pin
        self.echo_pin = echo_pin
        self.float_pins = float_pins or []
        self.adc = None
        self.adc_channel = None
        self.serial = None
        
        # Tank measurements for percentage calculation
        self.tank_height_cm = tank_height_cm
        self.tank_empty_distance = tank_empty_distance
        self.tank_full_distance = tank_full_distance
        
        # Call parent initializer
        super().__init__(
            name=name,
            sensor_type="water_level",
            pin=pin,
            channel=channel,
            port=port,
            i2c_address=i2c_address,
            config=config or {}
        )
    
    def setup(self) -> bool:
        """Set up the water level sensor hardware connection."""
        if not HARDWARE_AVAILABLE:
            logger.warning("Hardware libraries not available, water level sensor will use simulated values")
            self.connected = True
            return True
            
        try:
            # Serial connection
            if self.port:
                logger.info(f"Setting up water level sensor on serial port {self.port}")
                self.serial = serial.Serial(
                    port=self.port,
                    baudrate=self.config.get('baudrate', 9600),
                    timeout=self.config.get('timeout', 1)
                )
                time.sleep(0.5)  # Allow time for serial connection
                self.connected = True
                return True
                
            # Ultrasonic sensor setup
            elif self.sensor_subtype == 'ultrasonic' and self.trigger_pin is not None and self.echo_pin is not None:
                logger.info(f"Setting up ultrasonic water level sensor on pins {self.trigger_pin} (trigger) and {self.echo_pin} (echo)")
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(self.trigger_pin, GPIO.OUT)
                GPIO.setup(self.echo_pin, GPIO.IN)
                GPIO.output(self.trigger_pin, False)
                time.sleep(0.5)  # Give sensor time to settle
                self.connected = True
                return True
                
            # Float switch array
            elif self.sensor_subtype == 'float' and self.float_pins:
                logger.info(f"Setting up float switch array on pins {self.float_pins}")
                GPIO.setmode(GPIO.BCM)
                for pin in self.float_pins:
                    GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
                self.connected = True
                return True
                
            # Single float switch
            elif self.sensor_subtype == 'float' and self.pin is not None:
                logger.info(f"Setting up float switch on pin {self.pin}")
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(self.pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
                self.connected = True
                return True
                
            # Capacitive or pressure sensor via ADC
            elif (self.sensor_subtype in ['capacitive', 'pressure']) and self.i2c_address is not None and self.channel is not None:
                logger.info(f"Setting up {self.sensor_subtype} water level sensor on ADC at address 0x{self.i2c_address:02X}, channel {self.channel}")
                
                # Create I2C bus
                i2c = busio.I2C(board.SCL, board.SDA)
                
                # Create ADC object
                if self.config.get('adc_type', '').upper() == "ADS1015":
                    self.adc = ADS1015.ADS1015(
                        i2c, 
                        address=self.i2c_address, 
                        gain=self.config.get('adc_gain', 1)
                    )
                else:  # Default to ADS1115
                    self.adc = ADS1115.ADS1115(
                        i2c, 
                        address=self.i2c_address, 
                        gain=self.config.get('adc_gain', 1)
                    )
                
                # Create analog input channel
                self.adc_channel = AnalogIn(self.adc, getattr(ADS, f'P{self.channel}'))
                
                # Test reading
                _ = self.adc_channel.voltage
                
                self.connected = True
                return True
                
            else:
                logger.error("No valid connection method specified for water level sensor")
                return False
                
        except Exception as e:
            logger.exception(f"Error setting up water level sensor: {str(e)}")
            self.connected = False
            return False
    
    def read_raw(self) -> Union[float, List[bool], None]:
        """
        Read raw data from the water level sensor.
        Returns distance (cm) for ultrasonic, voltage for analog, state array for float switches.
        """
        # If not in hardware mode, return simulated value
        if not HARDWARE_AVAILABLE:
            import random
            # Simulate a distance between full and empty
            return random.uniform(self.tank_full_distance, self.tank_empty_distance)
        
        try:
            # Ultrasonic sensor
            if self.sensor_subtype == 'ultrasonic' and self.trigger_pin is not None and self.echo_pin is not None:
                # Send trigger pulse
                GPIO.output(self.trigger_pin, True)
                time.sleep(0.00001)  # 10 microsecond pulse
                GPIO.output(self.trigger_pin, False)
                
                # Wait for echo pin to go high
                pulse_start = time.time()
                timeout_start = pulse_start
                while GPIO.input(self.echo_pin) == 0:
                    pulse_start = time.time()
                    if pulse_start - timeout_start > 0.1:  # 100ms timeout
                        logger.warning("Ultrasonic sensor echo pin timeout waiting for HIGH")
                        return None
                
                # Wait for echo pin to go low
                pulse_end = time.time()
                timeout_start = pulse_end
                while GPIO.input(self.echo_pin) == 1:
                    pulse_end = time.time()
                    if pulse_end - timeout_start > 0.1:  # 100ms timeout
                        logger.warning("Ultrasonic sensor echo pin timeout waiting for LOW")
                        return None
                
                # Calculate distance
                pulse_duration = pulse_end - pulse_start
                distance_cm = (pulse_duration * self.SPEED_OF_SOUND) / 2
                
                # Constrain to reasonable values
                if distance_cm < 0 or distance_cm > 400:  # Most ultrasonic sensors have max range of 400cm
                    logger.warning(f"Ultrasonic sensor returned unreasonable distance: {distance_cm}cm")
                    return None
                
                return distance_cm
                
            # Float switch array
            elif self.sensor_subtype == 'float' and self.float_pins:
                # Read all float switches
                switch_states = [GPIO.input(pin) for pin in self.float_pins]
                return switch_states
                
            # Single float switch
            elif self.sensor_subtype == 'float' and self.pin is not None:
                return GPIO.input(self.pin)
                
            # Capacitive or pressure sensor via ADC
            elif self.adc_channel:
                return self.adc_channel.voltage
                
            # Serial sensor
            elif self.serial:
                self.serial.write(b"R\r")  # Common command to request reading
                time.sleep(0.1)
                if self.serial.in_waiting:
                    response = self.serial.readline().decode('ascii').strip()
                    try:
                        return float(response)
                    except ValueError:
                        if ":" in response:
                            return float(response.split(":", 1)[1])
                        logger.error(f"Unable to parse water level from serial: {response}")
                        return None
                else:
                    logger.warning("No data received from serial water level sensor")
                    return None
                    
            else:
                logger.error("No configured connection method for water level sensor")
                return None
                
        except Exception as e:
            logger.exception(f"Error reading from water level sensor: {str(e)}")
            return None
    
    def convert_reading(self, raw_value: Any) -> float:
        """
        Convert raw sensor data to water level percentage.
        
        Args:
            raw_value: The raw value from read_raw()
            
        Returns:
            Water level as a percentage (0-100%)
        """
        if raw_value is None:
            return None
        
        # Apply any general calibration
        calibrated_value = self.apply_calibration(raw_value) if isinstance(raw_value, (int, float)) else raw_value
        
        # For float switch array
        if isinstance(calibrated_value, list):
            # Count number of switches that are activated
            # Assuming LOW is activated for the float switches
            activated_switches = calibrated_value.count(0)  # Count LOW values
            if not activated_switches:
                return 0  # Empty tank
            
            # Calculate percentage based on number of activated switches
            percentage = (activated_switches / len(calibrated_value)) * 100
            return round(percentage)
            
        # For single float switch
        elif self.sensor_subtype == 'float' and self.pin is not None:
            # Assuming LOW is activated
            # This would typically just indicate a single threshold has been reached
            return 100 if calibrated_value == 0 else 0
            
        # For ultrasonic sensor (distance reading)
        elif self.sensor_subtype == 'ultrasonic':
            # Convert distance to percentage
            # When water level is high, distance reading is low (and vice versa)
            distance_range = self.tank_empty_distance - self.tank_full_distance
            if distance_range <= 0:
                logger.error("Invalid tank distance configuration: empty distance must be greater than full distance")
                return 0
                
            water_level_percent = 100 - ((calibrated_value - self.tank_full_distance) / distance_range * 100)
            
            # Constrain to 0-100%
            water_level_percent = max(0, min(100, water_level_percent))
            
            return round(water_level_percent)
            
        # For voltage-based sensors (capacitive, pressure)
        elif self.sensor_subtype in ['capacitive', 'pressure']:
            # Convert voltage to percentage based on calibration
            # This assumes voltage increases with water level
            min_voltage = self.config.get('min_voltage', 0.0)
            max_voltage = self.config.get('max_voltage', 3.3)
            voltage_range = max_voltage - min_voltage
            
            if voltage_range <= 0:
                logger.error("Invalid voltage calibration: max_voltage must be greater than min_voltage")
                return 0
                
            water_level_percent = ((calibrated_value - min_voltage) / voltage_range) * 100
            
            # Constrain to 0-100%
            water_level_percent = max(0, min(100, water_level_percent))
            
            return round(water_level_percent)
            
        # For serial sensors sending direct percentage
        elif self.serial and isinstance(calibrated_value, (int, float)):
            # Constrain to 0-100%
            return round(max(0, min(100, calibrated_value)))
            
        else:
            logger.error(f"Unsupported raw value type: {type(calibrated_value)}")
            return 0