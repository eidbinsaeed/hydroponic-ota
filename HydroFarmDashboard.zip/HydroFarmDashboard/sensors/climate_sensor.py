"""
Climate sensor implementation for the Hydroponic Farm Dashboard.
Supports DHT11/DHT22/AM2302 temperature and humidity sensors.
"""

import logging
import time
from typing import Dict, Any, Optional, Union, Tuple

try:
    import Adafruit_DHT
    import RPi.GPIO as GPIO
    HARDWARE_AVAILABLE = True
except (ImportError, RuntimeError):
    HARDWARE_AVAILABLE = False

from .sensor_interface import SensorInterface

# Setup logging
logger = logging.getLogger(__name__)

class ClimateSensor(SensorInterface):
    """Temperature and humidity sensor implementation supporting DHT11/DHT22/AM2302."""
    
    # Sensor model constants
    DHT11 = 11
    DHT22 = 22
    AM2302 = 22  # AM2302 is electrically identical to DHT22
    
    def __init__(
        self,
        name: str = "Climate Sensor",
        pin: Optional[int] = None,
        sensor_model: int = DHT22,  # Default to DHT22 which is more accurate
        read_retries: int = 3,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize a temperature/humidity sensor with hardware configuration.
        
        Args:
            name: Human-readable name for this sensor
            pin: GPIO pin number connected to the data line of the DHT sensor
            sensor_model: Type of DHT sensor (11 for DHT11, 22 for DHT22/AM2302)
            read_retries: Number of times to retry reading if unsuccessful
            config: Additional sensor-specific configuration
        """
        self.sensor_model = sensor_model
        self.read_retries = read_retries
        self.last_temperature = None
        self.last_humidity = None
        
        # Call parent initializer
        super().__init__(
            name=name,
            sensor_type="climate",
            pin=pin,
            config=config or {}
        )
    
    def setup(self) -> bool:
        """Set up the climate sensor hardware connection."""
        if not HARDWARE_AVAILABLE:
            logger.warning("Hardware libraries not available, climate sensor will use simulated values")
            self.connected = True
            return True
            
        try:
            if self.pin is None:
                logger.error("No pin specified for DHT sensor")
                return False
                
            # No specific setup required for DHT sensors
            # Just verify we can take a reading
            humidity, temperature = Adafruit_DHT.read_retry(self.sensor_model, self.pin, retries=1)
            if humidity is not None and temperature is not None:
                logger.info(f"Successfully connected to DHT{self.sensor_model} sensor on pin {self.pin}")
                self.connected = True
                return True
            else:
                logger.warning(f"DHT{self.sensor_model} sensor on pin {self.pin} did not return a valid reading")
                return False
                
        except Exception as e:
            logger.exception(f"Error setting up climate sensor: {str(e)}")
            self.connected = False
            return False
    
    def read_raw(self) -> Union[Tuple[float, float], None]:
        """
        Read raw data from the climate sensor.
        Returns (humidity, temperature) tuple.
        """
        # If not in hardware mode, return simulated values
        if not HARDWARE_AVAILABLE:
            import random
            # Simulate temperature between 18-28°C and humidity between 40-70%
            return (
                random.uniform(40.0, 70.0),  # Humidity %
                random.uniform(18.0, 28.0)   # Temperature °C
            )
        
        try:
            if self.pin is None:
                logger.error("No pin specified for DHT sensor")
                return None
                
            # Read from DHT sensor with retries
            humidity, temperature = Adafruit_DHT.read_retry(
                self.sensor_model, self.pin, retries=self.read_retries
            )
            
            if humidity is None or temperature is None:
                logger.warning(f"Failed to get reading from DHT{self.sensor_model} sensor")
                return None
                
            return (humidity, temperature)
                
        except Exception as e:
            logger.exception(f"Error reading from climate sensor: {str(e)}")
            return None
    
    def convert_reading(self, raw_value: Any) -> Dict[str, float]:
        """
        Convert raw sensor data to meaningful temperature and humidity values.
        
        Args:
            raw_value: The raw value from read_raw() - should be (humidity, temperature) tuple
            
        Returns:
            Dict with 'temperature' and 'humidity' keys
        """
        if raw_value is None:
            return None
            
        if not isinstance(raw_value, tuple) or len(raw_value) != 2:
            logger.error(f"Invalid climate sensor raw value: {raw_value}")
            return None
            
        humidity, temperature = raw_value
        
        # Apply calibration if available
        if 'temperature_offset' in self.config:
            temperature += self.config.get('temperature_offset', 0.0)
            
        if 'humidity_offset' in self.config:
            humidity += self.config.get('humidity_offset', 0.0)
            
        # Constrain values to realistic ranges
        humidity = max(0.0, min(100.0, humidity))
        
        # Store the values
        self.last_temperature = round(temperature, 1)
        self.last_humidity = round(humidity, 1)
        
        return {
            'temperature': self.last_temperature,
            'humidity': self.last_humidity
        }
    
    def read(self) -> Tuple[Dict[str, float], bool]:
        """
        Read and process sensor data with error handling.
        
        Returns:
            Tuple of (readings dict, success flag)
        """
        try:
            if not self.connected and not self.setup():
                return None, False
                
            raw_data = self.read_raw()
            if raw_data is None:
                self.error_count += 1
                logger.warning(f"Failed to read from sensor: {self.name}")
                return None, False
                
            readings = self.convert_reading(raw_data)
            if readings is None:
                self.error_count += 1
                return None, False
                
            self.last_reading = readings
            self.last_reading_time = time.time()
            self.error_count = 0
            return readings, True
            
        except Exception as e:
            self.error_count += 1
            logger.exception(f"Error reading from sensor {self.name}: {str(e)}")
            
            # If too many errors, try to re-initialize
            if self.error_count >= self.max_errors:
                logger.warning(f"Too many errors from sensor {self.name}, attempting reconnection")
                self.setup()
                
            return None, False
    
    def calibrate_climate(self, reference_temperature: float = None, reference_humidity: float = None) -> bool:
        """
        Calibrate the climate sensor using reference measurements.
        
        Args:
            reference_temperature: Known accurate temperature for calibration
            reference_humidity: Known accurate humidity for calibration
            
        Returns:
            True if calibration successful
        """
        try:
            # Read current values
            raw_data = self.read_raw()
            if raw_data is None:
                return False
                
            humidity, temperature = raw_data
            
            # Calculate offsets
            if reference_temperature is not None:
                temp_offset = reference_temperature - temperature
                self.config['temperature_offset'] = temp_offset
                logger.info(f"Temperature calibration offset: {temp_offset:.2f}°C")
                
            if reference_humidity is not None:
                humidity_offset = reference_humidity - humidity
                self.config['humidity_offset'] = humidity_offset
                logger.info(f"Humidity calibration offset: {humidity_offset:.2f}%")
                
            return True
            
        except Exception as e:
            logger.exception(f"Error calibrating climate sensor: {str(e)}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of the sensor.
        
        Returns:
            Dict with sensor status information
        """
        status = super().get_status()
        
        # Add climate-specific status info
        status.update({
            'temperature': self.last_temperature,
            'humidity': self.last_humidity,
            'model': f"DHT{self.sensor_model}"
        })
        
        return status