"""
Sensor manager for the Hydroponic Farm Dashboard.
Handles creation, reading, and management of all connected sensors.
"""

import logging
import time
import json
import os
from typing import Dict, List, Any, Optional, Tuple

from .sensor_interface import SensorInterface
from .ph_sensor import PHSensor
from .water_level_sensor import WaterLevelSensor
from .climate_sensor import ClimateSensor

# Setup logging
logger = logging.getLogger(__name__)

class SensorManager:
    """Manager class for all sensors in the hydroponic system."""
    
    # File to store sensor configurations
    SENSOR_CONFIG_FILE = "sensor_config.json"
    
    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the sensor manager.
        
        Args:
            config_file: Path to configuration file (default: sensor_config.json)
        """
        self.sensors: Dict[str, SensorInterface] = {}
        self.config_file = config_file or self.SENSOR_CONFIG_FILE
        self.last_readings: Dict[str, Any] = {}
        self.config = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """
        Load sensor configuration from file or create with defaults.
        
        Returns:
            Dict containing sensor configurations
        """
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                logger.info(f"Loaded sensor configuration from {self.config_file}")
                return config
            except Exception as e:
                logger.error(f"Error loading sensor configuration: {str(e)}")
                return self._get_default_config()
        else:
            # Create default config
            config = self._get_default_config()
            self._save_config(config)
            return config
    
    def _save_config(self, config: Dict[str, Any]) -> bool:
        """
        Save sensor configuration to file.
        
        Args:
            config: Configuration dictionary to save
            
        Returns:
            True if saved successfully, False otherwise
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            logger.info(f"Saved sensor configuration to {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"Error saving sensor configuration: {str(e)}")
            return False
    
    def _get_default_config(self) -> Dict[str, Any]:
        """
        Get default sensor configuration.
        
        Returns:
            Dict with default sensor configurations
        """
        return {
            "sensors": {
                "ph": {
                    "enabled": True,
                    "type": "ph",
                    "interface": "i2c",
                    "i2c_address": 0x48,
                    "channel": 0,
                    "calibration": {
                        "ph_4_voltage": 3.1,
                        "ph_7_voltage": 2.5
                    }
                },
                "water_level": {
                    "enabled": True,
                    "type": "water_level",
                    "subtype": "ultrasonic",
                    "interface": "gpio",
                    "trigger_pin": 23,
                    "echo_pin": 24,
                    "tank_height_cm": 30.0,
                    "tank_empty_distance": 25.0,
                    "tank_full_distance": 5.0
                },
                "climate": {
                    "enabled": True,
                    "type": "climate",
                    "interface": "gpio",
                    "pin": 4,  # Standard GPIO pin for DHT sensors
                    "sensor_model": 22,  # DHT22 by default (more accurate)
                    "read_retries": 3,
                    "calibration": {
                        "temperature_offset": 0.0,
                        "humidity_offset": 0.0
                    }
                }
            }
        }
    
    def initialize_sensors(self) -> bool:
        """
        Initialize all sensors based on configuration.
        
        Returns:
            True if any sensors were successfully initialized
        """
        if not self.config or "sensors" not in self.config:
            logger.error("No valid sensor configuration found")
            return False
            
        success = False
        
        # Clear existing sensors
        self.sensors = {}
        
        # Initialize each configured sensor
        for sensor_id, sensor_config in self.config["sensors"].items():
            if not sensor_config.get("enabled", True):
                logger.info(f"Skipping disabled sensor: {sensor_id}")
                continue
                
            sensor_type = sensor_config.get("type", "")
            
            try:
                if sensor_type == "ph":
                    sensor = self._create_ph_sensor(sensor_id, sensor_config)
                elif sensor_type == "water_level":
                    sensor = self._create_water_level_sensor(sensor_id, sensor_config)
                elif sensor_type == "climate":
                    sensor = self._create_climate_sensor(sensor_id, sensor_config)
                else:
                    logger.warning(f"Unsupported sensor type: {sensor_type}")
                    continue
                    
                if sensor and sensor.connected:
                    self.sensors[sensor_id] = sensor
                    logger.info(f"Successfully initialized {sensor_type} sensor: {sensor_id}")
                    success = True
                else:
                    logger.warning(f"Failed to initialize {sensor_type} sensor: {sensor_id}")
                    
            except Exception as e:
                logger.exception(f"Error initializing sensor {sensor_id}: {str(e)}")
        
        return success
    
    def _create_ph_sensor(self, sensor_id: str, config: Dict[str, Any]) -> Optional[PHSensor]:
        """
        Create a pH sensor from configuration.
        
        Args:
            sensor_id: Unique identifier for this sensor
            config: Configuration dictionary for this sensor
            
        Returns:
            Initialized PHSensor object or None if creation failed
        """
        interface = config.get("interface", "i2c")
        
        # Common parameters
        params = {
            "name": config.get("name", f"pH Sensor ({sensor_id})"),
            "config": config.get("calibration", {})
        }
        
        # Interface-specific parameters
        if interface == "i2c":
            params.update({
                "i2c_address": config.get("i2c_address", 0x48),
                "channel": config.get("channel", 0),
                "adc_gain": config.get("adc_gain", 1),
                "adc_type": config.get("adc_type", "ADS1115")
            })
        elif interface == "serial":
            params.update({
                "port": config.get("port", "/dev/ttyUSB0"),
            })
        elif interface == "gpio":
            params.update({
                "pin": config.get("pin")
            })
            
        # Create and return the sensor
        sensor = PHSensor(**params)
        
        # Apply calibration if provided
        cal_data = config.get("calibration", {})
        if "ph_4_voltage" in cal_data and "ph_7_voltage" in cal_data:
            sensor.calibrate_ph(cal_data["ph_4_voltage"], cal_data["ph_7_voltage"])
            
        return sensor
    
    def _create_water_level_sensor(self, sensor_id: str, config: Dict[str, Any]) -> Optional[WaterLevelSensor]:
        """
        Create a water level sensor from configuration.
        
        Args:
            sensor_id: Unique identifier for this sensor
            config: Configuration dictionary for this sensor
            
        Returns:
            Initialized WaterLevelSensor object or None if creation failed
        """
        interface = config.get("interface", "gpio")
        subtype = config.get("subtype", "ultrasonic")
        
        # Common parameters
        params = {
            "name": config.get("name", f"Water Level Sensor ({sensor_id})"),
            "sensor_subtype": subtype,
            "tank_height_cm": config.get("tank_height_cm", 30.0),
            "tank_empty_distance": config.get("tank_empty_distance", 25.0),
            "tank_full_distance": config.get("tank_full_distance", 5.0),
            "config": config.get("calibration", {})
        }
        
        # Interface and subtype specific parameters
        if interface == "gpio" and subtype == "ultrasonic":
            params.update({
                "trigger_pin": config.get("trigger_pin"),
                "echo_pin": config.get("echo_pin")
            })
        elif interface == "gpio" and subtype == "float":
            if "float_pins" in config:
                params.update({
                    "float_pins": config.get("float_pins", [])
                })
            else:
                params.update({
                    "pin": config.get("pin")
                })
        elif interface == "i2c" and subtype in ["capacitive", "pressure"]:
            params.update({
                "i2c_address": config.get("i2c_address", 0x48),
                "channel": config.get("channel", 0),
            })
            if "min_voltage" in config and "max_voltage" in config:
                params["config"].update({
                    "min_voltage": config.get("min_voltage"),
                    "max_voltage": config.get("max_voltage")
                })
        elif interface == "serial":
            params.update({
                "port": config.get("port", "/dev/ttyUSB0"),
            })
            
        # Create and return the sensor
        return WaterLevelSensor(**params)
    
    def _create_climate_sensor(self, sensor_id: str, config: Dict[str, Any]) -> Optional[ClimateSensor]:
        """
        Create a climate sensor from configuration.
        
        Args:
            sensor_id: Unique identifier for this sensor
            config: Configuration dictionary for this sensor
            
        Returns:
            Initialized ClimateSensor object or None if creation failed
        """
        # Get common parameters
        interface = config.get("interface", "gpio")
        
        # Common parameters
        params = {
            "name": config.get("name", f"Climate Sensor ({sensor_id})"),
            "pin": config.get("pin"),
            "sensor_model": config.get("sensor_model", ClimateSensor.DHT22),
            "read_retries": config.get("read_retries", 3)
        }
        
        # Add any calibration data to the config
        cal_data = config.get("calibration", {})
        params["config"] = cal_data
        
        # Create the sensor
        sensor = ClimateSensor(**params)
        
        return sensor

    def read_all_sensors(self) -> Dict[str, Any]:
        """
        Read data from all sensors.
        
        Returns:
            Dict with readings from all sensors
        """
        readings = {}
        
        for sensor_id, sensor in self.sensors.items():
            value, success = sensor.read()
            if success:
                # Special handling for climate sensor which returns a dict
                if sensor_id == "climate" and isinstance(value, dict):
                    # Add temperature and humidity as separate readings
                    readings["temperature"] = value.get("temperature")
                    readings["humidity"] = value.get("humidity")
                else:
                    readings[sensor_id] = value
                
                self.last_readings[sensor_id] = value
            else:
                # Use last good reading if available
                if sensor_id == "climate" and sensor_id in self.last_readings:
                    last_value = self.last_readings.get(sensor_id)
                    if isinstance(last_value, dict):
                        readings["temperature"] = last_value.get("temperature")
                        readings["humidity"] = last_value.get("humidity")
                else:
                    readings[sensor_id] = self.last_readings.get(sensor_id)
                
        return readings
    
    def read_sensor(self, sensor_id: str) -> Tuple[Any, bool]:
        """
        Read data from a specific sensor.
        
        Args:
            sensor_id: ID of the sensor to read
            
        Returns:
            Tuple of (sensor reading, success flag)
        """
        if sensor_id not in self.sensors:
            logger.error(f"Sensor {sensor_id} not found")
            return None, False
            
        return self.sensors[sensor_id].read()
    
    def get_sensor_ids(self) -> List[str]:
        """
        Get list of all sensor IDs.
        
        Returns:
            List of sensor IDs
        """
        return list(self.sensors.keys())
    
    def get_sensor_types(self) -> Dict[str, str]:
        """
        Get mapping of sensor IDs to types.
        
        Returns:
            Dict mapping sensor IDs to their types
        """
        return {sensor_id: sensor.sensor_type for sensor_id, sensor in self.sensors.items()}
    
    def get_sensor_statuses(self) -> Dict[str, Dict[str, Any]]:
        """
        Get status information for all sensors.
        
        Returns:
            Dict with status info for each sensor
        """
        return {sensor_id: sensor.get_status() for sensor_id, sensor in self.sensors.items()}
    
    def calibrate_sensor(self, sensor_id: str, calibration_data: Dict[str, Any]) -> bool:
        """
        Calibrate a specific sensor.
        
        Args:
            sensor_id: ID of the sensor to calibrate
            calibration_data: Calibration parameters
            
        Returns:
            True if calibration was successful
        """
        if sensor_id not in self.sensors:
            logger.error(f"Sensor {sensor_id} not found")
            return False
            
        sensor = self.sensors[sensor_id]
        
        if sensor.sensor_type == "ph":
            if "ph_4_voltage" in calibration_data and "ph_7_voltage" in calibration_data:
                result = sensor.calibrate_ph(
                    calibration_data["ph_4_voltage"],
                    calibration_data["ph_7_voltage"]
                )
                
                # Update configuration file
                if result and sensor_id in self.config["sensors"]:
                    if "calibration" not in self.config["sensors"][sensor_id]:
                        self.config["sensors"][sensor_id]["calibration"] = {}
                    
                    self.config["sensors"][sensor_id]["calibration"].update({
                        "ph_4_voltage": calibration_data["ph_4_voltage"],
                        "ph_7_voltage": calibration_data["ph_7_voltage"]
                    })
                    self._save_config(self.config)
                
                return result
            else:
                logger.error("Missing required calibration data for pH sensor")
                return False
                
        elif sensor.sensor_type == "water_level":
            # Handle different water level sensor calibrations
            if sensor.sensor_subtype in ["capacitive", "pressure"] and "min_voltage" in calibration_data and "max_voltage" in calibration_data:
                # Update sensor config
                sensor.config["min_voltage"] = calibration_data["min_voltage"]
                sensor.config["max_voltage"] = calibration_data["max_voltage"]
                
                # Update configuration file
                if sensor_id in self.config["sensors"]:
                    if "calibration" not in self.config["sensors"][sensor_id]:
                        self.config["sensors"][sensor_id]["calibration"] = {}
                    
                    self.config["sensors"][sensor_id]["calibration"].update({
                        "min_voltage": calibration_data["min_voltage"],
                        "max_voltage": calibration_data["max_voltage"]
                    })
                    self._save_config(self.config)
                
                return True
                
            elif sensor.sensor_subtype == "ultrasonic" and "tank_empty_distance" in calibration_data and "tank_full_distance" in calibration_data:
                # Update sensor properties
                sensor.tank_empty_distance = calibration_data["tank_empty_distance"]
                sensor.tank_full_distance = calibration_data["tank_full_distance"]
                
                # Update configuration file
                if sensor_id in self.config["sensors"]:
                    self.config["sensors"][sensor_id].update({
                        "tank_empty_distance": calibration_data["tank_empty_distance"],
                        "tank_full_distance": calibration_data["tank_full_distance"]
                    })
                    self._save_config(self.config)
                
                return True
                
            else:
                logger.error(f"Missing or invalid calibration data for {sensor.sensor_subtype} water level sensor")
                return False
        else:
            logger.error(f"Calibration not implemented for sensor type: {sensor.sensor_type}")
            return False