"""
pH sensor implementation for the Hydroponic Farm Dashboard.
Supports both direct ADC connection and serial communication.
"""

import logging
import time
from typing import Dict, Any, Optional, Union
import serial

try:
    import busio
    import board
    import RPi.GPIO as GPIO
    from adafruit_ads1x15.ads1x15 import ADS
    from adafruit_ads1x15.analog_in import AnalogIn
    import adafruit_ads1x15.ads1115 as ADS1115
    import adafruit_ads1x15.ads1015 as ADS1015
    HARDWARE_AVAILABLE = True
except (ImportError, RuntimeError):
    HARDWARE_AVAILABLE = False

from .sensor_interface import SensorInterface

# Setup logging
logger = logging.getLogger(__name__)

class PHSensor(SensorInterface):
    """pH sensor implementation supporting GPIO/ADC and serial interfaces."""
    
    # Default calibration values for pH (can be overridden through calibration)
    DEFAULT_PH_4_VOLTAGE = 3.1    # Typical voltage at pH 4
    DEFAULT_PH_7_VOLTAGE = 2.5    # Typical voltage at pH 7
    
    def __init__(
        self,
        name: str = "pH Sensor",
        pin: Optional[int] = None,
        channel: Optional[int] = 0,
        port: Optional[str] = None,
        i2c_address: Optional[int] = 0x48,
        adc_gain: int = 1,
        adc_data_rate: int = 128,
        adc_type: str = "ADS1115",
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize a pH sensor with hardware configuration.
        
        Args:
            name: Human-readable name for this sensor
            pin: GPIO pin number if using direct GPIO (not typically used for pH)
            channel: ADC channel number (0-3) if using an ADC
            port: Serial port path if using serial communication (e.g., '/dev/ttyUSB0')
            i2c_address: I2C address of ADC (default: 0x48)
            adc_gain: ADC gain setting (1, 2, 4, 8, 16)
            adc_data_rate: ADC data rate in samples per second
            adc_type: Type of ADC ('ADS1115' or 'ADS1015')
            config: Additional sensor-specific configuration
        """
        self.adc = None
        self.serial = None
        self.adc_channel = None
        self.adc_gain = adc_gain
        self.adc_data_rate = adc_data_rate
        self.adc_type = adc_type
        
        # pH-specific calibration points (voltage to pH mapping)
        self.ph_4_voltage = config.get('ph_4_voltage', self.DEFAULT_PH_4_VOLTAGE) if config else self.DEFAULT_PH_4_VOLTAGE
        self.ph_7_voltage = config.get('ph_7_voltage', self.DEFAULT_PH_7_VOLTAGE) if config else self.DEFAULT_PH_7_VOLTAGE
        
        # Call parent initializer
        super().__init__(
            name=name,
            sensor_type="ph",
            pin=pin,
            channel=channel,
            port=port,
            i2c_address=i2c_address,
            config=config
        )
        
    def setup(self) -> bool:
        """Set up the pH sensor hardware connection."""
        if not HARDWARE_AVAILABLE:
            logger.warning("Hardware libraries not available, pH sensor will use simulated values")
            self.connected = True
            return True
            
        try:
            # If serial port is specified, use serial communication
            if self.port:
                logger.info(f"Setting up pH sensor on serial port {self.port}")
                self.serial = serial.Serial(
                    port=self.port,
                    baudrate=self.config.get('baudrate', 9600),
                    timeout=self.config.get('timeout', 1)
                )
                time.sleep(0.5)  # Allow time for serial connection to stabilize
                self.connected = True
                return True
                
            # Otherwise, use I2C/ADC
            elif self.i2c_address is not None and self.channel is not None:
                logger.info(f"Setting up pH sensor on ADC at address 0x{self.i2c_address:02X}, channel {self.channel}")
                
                # Create I2C bus
                i2c = busio.I2C(board.SCL, board.SDA)
                
                # Create the ADC object
                if self.adc_type.upper() == "ADS1015":
                    self.adc = ADS1015.ADS1015(i2c, address=self.i2c_address, gain=self.adc_gain, data_rate=self.adc_data_rate)
                else:  # Default to ADS1115
                    self.adc = ADS1115.ADS1115(i2c, address=self.i2c_address, gain=self.adc_gain, data_rate=self.adc_data_rate)
                
                # Create single-ended input on specified channel
                self.adc_channel = AnalogIn(self.adc, getattr(ADS, f'P{self.channel}'))
                
                # Test reading
                _ = self.adc_channel.voltage
                
                self.connected = True
                logger.info(f"Successfully connected to pH sensor via ADC on channel {self.channel}")
                return True
                
            # Use direct GPIO (not common for pH sensors that typically need ADC)
            elif self.pin is not None:
                logger.warning("Direct GPIO connection for pH sensors is not recommended due to analog nature")
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(self.pin, GPIO.IN)
                self.connected = True
                return True
                
            else:
                logger.error("No valid connection method specified for pH sensor")
                return False
                
        except Exception as e:
            logger.exception(f"Error setting up pH sensor: {str(e)}")
            self.connected = False
            return False
            
    def read_raw(self) -> Union[float, None]:
        """
        Read raw data from the pH sensor.
        Returns voltage for ADC, or raw pH value for serial.
        """
        # If not in hardware mode, return simulated value
        if not HARDWARE_AVAILABLE:
            import random
            # Simulate pH voltage between 2.5 and 3.1 (pH 7-4)
            return random.uniform(2.5, 3.1)
        
        try:
            # Read from serial port
            if self.serial:
                self.serial.write(b"R\r")  # Common command to request reading
                time.sleep(0.1)
                if self.serial.in_waiting:
                    response = self.serial.readline().decode('ascii').strip()
                    # Parse response based on device protocol
                    # Example format: "pH:6.8" or just "6.8"
                    if ":" in response:
                        return float(response.split(":", 1)[1])
                    else:
                        try:
                            return float(response)
                        except ValueError:
                            logger.error(f"Unable to parse pH from serial: {response}")
                            return None
                else:
                    logger.warning("No data received from serial pH sensor")
                    return None
            
            # Read from ADC
            elif self.adc_channel:
                # Get voltage from ADC
                voltage = self.adc_channel.voltage
                return voltage
                
            # Read from GPIO (not typical for pH)
            elif self.pin is not None:
                logger.warning("Direct GPIO reading not recommended for pH sensors")
                return GPIO.input(self.pin)
                
            else:
                logger.error("No configured connection method for pH sensor")
                return None
                
        except Exception as e:
            logger.exception(f"Error reading from pH sensor: {str(e)}")
            return None
            
    def convert_reading(self, raw_value: float) -> float:
        """
        Convert raw pH sensor reading to calibrated pH value.
        
        Args:
            raw_value: The raw value (voltage from ADC or pH from serial)
            
        Returns:
            Calibrated pH value
        """
        if raw_value is None:
            return None
            
        # If we received from serial and it's already in pH units
        if self.serial and self.port:
            # Some serial sensors might still need calibration
            return self.apply_calibration(raw_value)
            
        # Convert voltage to pH using calibration points
        if 'slope' in self.calibration_data:
            # Use calibration from SensorInterface
            return self.apply_calibration(raw_value)
        else:
            # Use two-point calibration specific to pH
            # pH sensor is typically inverse relationship: lower voltage = higher pH
            voltage_diff = self.ph_4_voltage - self.ph_7_voltage
            ph_diff = 7.0 - 4.0  # pH difference between calibration points
            slope = ph_diff / voltage_diff
            
            # Calculate pH from voltage
            ph_value = 7.0 - (raw_value - self.ph_7_voltage) * slope
            
            return round(ph_value, 1)  # Round to 1 decimal place
            
    def calibrate_ph(self, ph4_voltage: float, ph7_voltage: float) -> bool:
        """
        Calibrate the pH sensor using standard buffer solutions.
        
        Args:
            ph4_voltage: Voltage reading when sensor is in pH 4 buffer
            ph7_voltage: Voltage reading when sensor is in pH 7 buffer
            
        Returns:
            True if calibration successful
        """
        if ph4_voltage is None or ph7_voltage is None:
            logger.error("Invalid calibration values for pH sensor")
            return False
            
        # Store calibration values
        self.ph_4_voltage = ph4_voltage
        self.ph_7_voltage = ph7_voltage
        
        # Add to calibration data
        self.calibration_data['ph_4_voltage'] = ph4_voltage
        self.calibration_data['ph_7_voltage'] = ph7_voltage
        
        # Calculate and store slope and intercept for apply_calibration
        voltage_diff = ph4_voltage - ph7_voltage
        ph_diff = 7.0 - 4.0
        
        if voltage_diff == 0:
            logger.error("pH calibration error: voltage readings are identical")
            return False
            
        slope = ph_diff / voltage_diff
        intercept = 7.0 - (ph7_voltage * slope)
        
        self.calibration_data['slope'] = slope
        self.calibration_data['intercept'] = intercept
        
        logger.info(f"pH sensor calibrated: ph = {slope:.4f} * voltage + {intercept:.4f}")
        return True